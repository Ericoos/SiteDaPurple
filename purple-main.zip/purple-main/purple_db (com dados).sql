-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 04/12/2024 às 06:29
-- Versão do servidor: 8.0.30
-- Versão do PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `purple_db`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `addnomecliente`
--

CREATE TABLE `addnomecliente` (
  `id_addNomeCliente` int NOT NULL,
  `id_evento` int DEFAULT NULL,
  `id_produto` int DEFAULT NULL,
  `id_cliente` int DEFAULT NULL,
  `nome_cliente` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `id_cadastro` int NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `imagem_perfil` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `sexo` varchar(10) DEFAULT NULL,
  `idade` int DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `cadastro`
--

INSERT INTO `cadastro` (`id_cadastro`, `nome`, `imagem_perfil`, `email`, `telefone`, `sexo`, `idade`, `senha`) VALUES
(1, 'Cliente comum 2', NULL, 'cliente@gmail.com', '(11) 96718-8305', 'masculino', 18, '$2y$10$Qu7TqYyUx9l7gP2nJ2EfyOrkZWmnwYBUeCRaaiSSput3/AGCaTZJ6');

-- --------------------------------------------------------

--
-- Estrutura para tabela `carrinho`
--

CREATE TABLE `carrinho` (
  `id_carrinho` int NOT NULL,
  `id_cadastro` int DEFAULT NULL,
  `id_evento` int DEFAULT NULL,
  `id_produto` int DEFAULT NULL,
  `status_carrinho` enum('Ativo','Finalizado') DEFAULT 'Ativo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `carrinho`
--

INSERT INTO `carrinho` (`id_carrinho`, `id_cadastro`, `id_evento`, `id_produto`, `status_carrinho`) VALUES
(1, 1, 1, NULL, 'Finalizado');

-- --------------------------------------------------------

--
-- Estrutura para tabela `carrinho_produtos`
--

CREATE TABLE `carrinho_produtos` (
  `id_carrinhoProd` int NOT NULL,
  `id_carrinho` int DEFAULT NULL,
  `id_produto` int DEFAULT NULL,
  `quantidade_produtos` int DEFAULT NULL,
  `valor_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `carrinho_produtos`
--

INSERT INTO `carrinho_produtos` (`id_carrinhoProd`, `id_carrinho`, `id_produto`, `quantidade_produtos`, `valor_total`) VALUES
(1, 1, 1, 20, 200.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `evento`
--

CREATE TABLE `evento` (
  `id_evento` int NOT NULL,
  `nome_evento` varchar(255) DEFAULT NULL,
  `quantidade_ingresso` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `descricao_evento` varchar(500) DEFAULT NULL,
  `data_evento` datetime DEFAULT NULL,
  `hora_evento` time NOT NULL,
  `cep_evento` varchar(255) NOT NULL,
  `rua_evento` varchar(255) NOT NULL,
  `complemento_evento` varchar(255) NOT NULL,
  `bairro_evento` varchar(255) NOT NULL,
  `localidade_evento` varchar(255) NOT NULL,
  `estado_evento` varchar(255) NOT NULL,
  `tipo_evento` varchar(255) NOT NULL,
  `id_loginOrg` int DEFAULT NULL,
  `banner` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `evento`
--

INSERT INTO `evento` (`id_evento`, `nome_evento`, `quantidade_ingresso`, `descricao_evento`, `data_evento`, `hora_evento`, `cep_evento`, `rua_evento`, `complemento_evento`, `bairro_evento`, `localidade_evento`, `estado_evento`, `tipo_evento`, `id_loginOrg`, `banner`) VALUES
(1, 'Festa da banca ', NULL, 'Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum ', '2024-12-17 00:00:00', '03:51:00', '04230-000', 'Avenida Almirante Delamare', 'Perto do Gula Bar', 'Cidade Nova Heliópolis', 'São Paulo', 'SP', 'show', 1, '674fdf5eb0f87-2020-12-20.png');

-- --------------------------------------------------------

--
-- Estrutura para tabela `historicoeventos`
--

CREATE TABLE `historicoeventos` (
  `id_historico` int NOT NULL,
  `evento_id` int DEFAULT NULL,
  `id_cliente` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `login_administrador`
--

CREATE TABLE `login_administrador` (
  `id_loginAdm` int NOT NULL,
  `senha` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `login_organizador`
--

CREATE TABLE `login_organizador` (
  `id_loginOrg` int NOT NULL,
  `senha_organizador` varchar(255) DEFAULT NULL,
  `nome_organizador` varchar(255) DEFAULT NULL,
  `descricao_organizador` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email_organizador` varchar(255) DEFAULT NULL,
  `telefone_organizador` varchar(20) DEFAULT NULL,
  `email_contato` varchar(255) DEFAULT NULL,
  `imagem_perfil` varchar(255) NOT NULL,
  `chave_pix` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `login_organizador`
--

INSERT INTO `login_organizador` (`id_loginOrg`, `senha_organizador`, `nome_organizador`, `descricao_organizador`, `email_organizador`, `telefone_organizador`, `email_contato`, `imagem_perfil`, `chave_pix`) VALUES
(1, '$2y$10$anolt2nr8N7iPR73qaw2BuB3WIXfnIQjTeGZbhGicFxjXRjITeiqa', 'André Kauã Leal Pereira 22323', 'contatoorganizador3@gmail.com', 'andrekaualeal@gmail.com', '(11) 95382-7857', 'andrekaualeal@gmail.com', '2020-12-20.png', ' chave pix aleatória');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamento`
--

CREATE TABLE `pagamento` (
  `id_pagamento` int NOT NULL,
  `forma_pagamento` varchar(50) DEFAULT NULL,
  `data_pagamento` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status_compra` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'Pendente',
  `id_carrinho` int DEFAULT NULL,
  `nome_pagamento` varchar(255) DEFAULT NULL,
  `email_pagamento` varchar(255) DEFAULT NULL,
  `telefone_pagamento` varchar(255) DEFAULT NULL,
  `id_carrinhoProd` int DEFAULT NULL,
  `id_cadastro` int NOT NULL,
  `id_evento` int DEFAULT NULL,
  `valor_totalpag` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `pagamento`
--

INSERT INTO `pagamento` (`id_pagamento`, `forma_pagamento`, `data_pagamento`, `status_compra`, `id_carrinho`, `nome_pagamento`, `email_pagamento`, `telefone_pagamento`, `id_carrinhoProd`, `id_cadastro`, `id_evento`, `valor_totalpag`) VALUES
(1, 'cartao', '2024-12-04 05:04:33', 'Expirado', 1, 'Erick', 'pagamento@gmail.com', '(11) 96718-8305', 1, 1, 1, 100.00),
(2, 'cartao', '2024-12-04 05:05:21', 'Expirado', 1, 'Erick 3', 'pagamento@gmail.com', '(12) 31231-2312', 1, 1, 1, 100.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `participacaoevento`
--

CREATE TABLE `participacaoevento` (
  `id_participacao` int NOT NULL,
  `id_evento` int DEFAULT NULL,
  `id_cadastro` int DEFAULT NULL,
  `id_pagamento` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `participacaoevento`
--

INSERT INTO `participacaoevento` (`id_participacao`, `id_evento`, `id_cadastro`, `id_pagamento`) VALUES
(1, 1, 1, 1),
(2, 1, 1, 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `produto`
--

CREATE TABLE `produto` (
  `id_produto` int NOT NULL,
  `id_evento` int DEFAULT NULL,
  `nome` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `valor` varchar(255) DEFAULT NULL,
  `quantidade` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `quantidade_pfesta` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `produto`
--

INSERT INTO `produto` (`id_produto`, `id_evento`, `nome`, `tipo`, `descricao`, `valor`, `quantidade`, `quantidade_pfesta`) VALUES
(1, 1, 'Ingresso Vip 22', 'ingresso', 'Da acesso a área vip', '10', '200', '180'),
(3, 1, 'Produto 1 (Beneficio)', 'beneficio', 'Produto 1 desc', '100', '200', '198'),
(4, 1, 'produto novo ', 'beneficio', '123213', '20', '40', '24');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos_evento`
--

CREATE TABLE `produtos_evento` (
  `id_prodEventos` int NOT NULL,
  `id_evento` int DEFAULT NULL,
  `quantidade` int DEFAULT NULL,
  `id_produto` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `addnomecliente`
--
ALTER TABLE `addnomecliente`
  ADD PRIMARY KEY (`id_addNomeCliente`),
  ADD KEY `id_evento` (`id_evento`),
  ADD KEY `id_produto` (`id_produto`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Índices de tabela `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`id_cadastro`);

--
-- Índices de tabela `carrinho`
--
ALTER TABLE `carrinho`
  ADD PRIMARY KEY (`id_carrinho`),
  ADD KEY `id_cliente` (`id_cadastro`),
  ADD KEY `fk_carrinho_evento` (`id_evento`),
  ADD KEY `fk_carrinho_produto` (`id_produto`);

--
-- Índices de tabela `carrinho_produtos`
--
ALTER TABLE `carrinho_produtos`
  ADD PRIMARY KEY (`id_carrinhoProd`),
  ADD KEY `id_carrinho` (`id_carrinho`),
  ADD KEY `id_produto` (`id_produto`);

--
-- Índices de tabela `evento`
--
ALTER TABLE `evento`
  ADD PRIMARY KEY (`id_evento`),
  ADD KEY `id_loginOrg` (`id_loginOrg`);

--
-- Índices de tabela `historicoeventos`
--
ALTER TABLE `historicoeventos`
  ADD PRIMARY KEY (`id_historico`),
  ADD KEY `evento_id` (`evento_id`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Índices de tabela `login_administrador`
--
ALTER TABLE `login_administrador`
  ADD PRIMARY KEY (`id_loginAdm`);

--
-- Índices de tabela `login_organizador`
--
ALTER TABLE `login_organizador`
  ADD PRIMARY KEY (`id_loginOrg`);

--
-- Índices de tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`id_pagamento`),
  ADD KEY `carrinho_id` (`id_carrinho`),
  ADD KEY `pagamento_ibfk_2` (`id_carrinhoProd`),
  ADD KEY `pagamento_ibfk_cadastro` (`id_cadastro`),
  ADD KEY `pagamento_ibfk_3` (`id_evento`);

--
-- Índices de tabela `participacaoevento`
--
ALTER TABLE `participacaoevento`
  ADD PRIMARY KEY (`id_participacao`),
  ADD KEY `evento_id` (`id_evento`),
  ADD KEY `id_cliente` (`id_cadastro`),
  ADD KEY `pagamento_id` (`id_pagamento`);

--
-- Índices de tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id_produto`),
  ADD KEY `id_evento` (`id_evento`);

--
-- Índices de tabela `produtos_evento`
--
ALTER TABLE `produtos_evento`
  ADD PRIMARY KEY (`id_prodEventos`),
  ADD KEY `id_evento` (`id_evento`),
  ADD KEY `id_produto` (`id_produto`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `addnomecliente`
--
ALTER TABLE `addnomecliente`
  MODIFY `id_addNomeCliente` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cadastro`
--
ALTER TABLE `cadastro`
  MODIFY `id_cadastro` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `carrinho`
--
ALTER TABLE `carrinho`
  MODIFY `id_carrinho` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `carrinho_produtos`
--
ALTER TABLE `carrinho_produtos`
  MODIFY `id_carrinhoProd` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `evento`
--
ALTER TABLE `evento`
  MODIFY `id_evento` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `historicoeventos`
--
ALTER TABLE `historicoeventos`
  MODIFY `id_historico` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `login_administrador`
--
ALTER TABLE `login_administrador`
  MODIFY `id_loginAdm` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `login_organizador`
--
ALTER TABLE `login_organizador`
  MODIFY `id_loginOrg` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `pagamento`
--
ALTER TABLE `pagamento`
  MODIFY `id_pagamento` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `participacaoevento`
--
ALTER TABLE `participacaoevento`
  MODIFY `id_participacao` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `id_produto` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `produtos_evento`
--
ALTER TABLE `produtos_evento`
  MODIFY `id_prodEventos` int NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `addnomecliente`
--
ALTER TABLE `addnomecliente`
  ADD CONSTRAINT `addnomecliente_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `addnomecliente_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`),
  ADD CONSTRAINT `addnomecliente_ibfk_3` FOREIGN KEY (`id_cliente`) REFERENCES `cadastro` (`id_cadastro`);

--
-- Restrições para tabelas `carrinho`
--
ALTER TABLE `carrinho`
  ADD CONSTRAINT `carrinho_ibfk_1` FOREIGN KEY (`id_cadastro`) REFERENCES `cadastro` (`id_cadastro`),
  ADD CONSTRAINT `fk_carrinho_evento` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_carrinho_produto` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `carrinho_produtos`
--
ALTER TABLE `carrinho_produtos`
  ADD CONSTRAINT `carrinho_produtos_ibfk_1` FOREIGN KEY (`id_carrinho`) REFERENCES `carrinho` (`id_carrinho`),
  ADD CONSTRAINT `carrinho_produtos_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`);

--
-- Restrições para tabelas `evento`
--
ALTER TABLE `evento`
  ADD CONSTRAINT `evento_ibfk_1` FOREIGN KEY (`id_loginOrg`) REFERENCES `login_organizador` (`id_loginOrg`);

--
-- Restrições para tabelas `historicoeventos`
--
ALTER TABLE `historicoeventos`
  ADD CONSTRAINT `historicoeventos_ibfk_1` FOREIGN KEY (`evento_id`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `historicoeventos_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `cadastro` (`id_cadastro`);

--
-- Restrições para tabelas `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `pagamento_ibfk_1` FOREIGN KEY (`id_carrinho`) REFERENCES `carrinho` (`id_carrinho`),
  ADD CONSTRAINT `pagamento_ibfk_2` FOREIGN KEY (`id_carrinhoProd`) REFERENCES `carrinho_produtos` (`id_carrinhoProd`),
  ADD CONSTRAINT `pagamento_ibfk_3` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `pagamento_ibfk_cadastro` FOREIGN KEY (`id_cadastro`) REFERENCES `cadastro` (`id_cadastro`);

--
-- Restrições para tabelas `participacaoevento`
--
ALTER TABLE `participacaoevento`
  ADD CONSTRAINT `participacaoevento_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `participacaoevento_ibfk_2` FOREIGN KEY (`id_cadastro`) REFERENCES `cadastro` (`id_cadastro`),
  ADD CONSTRAINT `participacaoevento_ibfk_3` FOREIGN KEY (`id_pagamento`) REFERENCES `pagamento` (`id_pagamento`);

--
-- Restrições para tabelas `produto`
--
ALTER TABLE `produto`
  ADD CONSTRAINT `produto_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`);

--
-- Restrições para tabelas `produtos_evento`
--
ALTER TABLE `produtos_evento`
  ADD CONSTRAINT `produtos_evento_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `produtos_evento_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
