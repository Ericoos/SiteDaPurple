<?php
session_start();
include_once('../bd/conexao.php');
include_once('../bd/festa.php');
include_once('../bd/carrinho.php'); // Incluindo a classe Carrinho

$connbanco = new banco();
$connbanco->conectar();

if (isset($_POST['id_evento'])) {
    $idEvento = filter_input(INPUT_POST, 'id_evento', FILTER_VALIDATE_INT);
} elseif (isset($_GET['id_evento'])) {
    $idEvento = filter_input(INPUT_GET, 'id_evento', FILTER_VALIDATE_INT);
} else {
    $_SESSION['mensagem'] = ['texto' => 'Evento não encontrado!', 'tipo' => 'erro'];
    header('Location: erro.php'); // Redireciona para uma página de erro
    exit;
}

if (isset($_SESSION['organizadores'])) {
    $userIdOrg = $_SESSION['organizadores']['id_loginOrg'];
} else {
    $_SESSION['mensagem'] = ['texto' => 'Não foi encontrado usuário!', 'tipo' => 'erro'];
    header('Location: login.php'); // Redireciona para login caso não encontre usuário
    exit;
}

$festa = new Festa();
$festaAtiva = $festa->verificarStatusFesta($idEvento);

$beneficios = $festa->buscarProdutosPorIdEvento($idEvento);
$totalBeneficios = count($beneficios);

// Instanciando a classe Carrinho
$carrinho = new Carrinho();

// Função de adicionar produto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adicionar_beneficio'])) {
    $nomeBeneficio = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $descricaoBeneficio = filter_input(INPUT_POST, 'descricao', FILTER_SANITIZE_STRING);
    $valorBeneficio = filter_input(INPUT_POST, 'valor', FILTER_VALIDATE_FLOAT);
    $quantidadeBeneficio = filter_input(INPUT_POST, 'quantidade', FILTER_VALIDATE_INT);
    $tipoBeneficio = filter_input(INPUT_POST, 'tipo', FILTER_SANITIZE_STRING);

    if ($festaAtiva == 'ativa' && $totalBeneficios < 10) {
        if (empty($nomeBeneficio) || empty($descricaoBeneficio) || $valorBeneficio === false || $quantidadeBeneficio === false || empty($tipoBeneficio)) {
            $_SESSION['mensagem'] = ['texto' => 'Por favor, preencha todos os campos corretamente.', 'tipo' => 'erro'];
        } else {
            if ($festa->adicionarBeneficio($idEvento, $nomeBeneficio, $descricaoBeneficio, $valorBeneficio, $quantidadeBeneficio, $tipoBeneficio)) {
                $_SESSION['mensagem'] = ['texto' => 'Produto adicionado com sucesso!', 'tipo' => 'sucesso'];
            } else {
                $_SESSION['mensagem'] = ['texto' => 'Erro ao adicionar produto.', 'tipo' => 'erro'];
            }
        }
    } else {
        $_SESSION['mensagem'] = ['texto' => 'A festa está inativa ou o limite de produtos foi atingido.', 'tipo' => 'erro'];
    }
    header("Location: beneficios.php.php?id_evento=$idEvento");
    exit;
}

// Função de edição de produto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_beneficio'])) {
    $idBeneficio = filter_input(INPUT_POST, 'id_produto', FILTER_VALIDATE_INT);
    $nomeBeneficio = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $descricaoBeneficio = filter_input(INPUT_POST, 'descricao', FILTER_SANITIZE_STRING);
    $valorBeneficio = filter_input(INPUT_POST, 'valor', FILTER_VALIDATE_FLOAT);
    $quantidadeBeneficio = filter_input(INPUT_POST, 'quantidade', FILTER_VALIDATE_INT);
    $tipoBeneficio = filter_input(INPUT_POST, 'tipo', FILTER_SANITIZE_STRING);

    if ($carrinho->verificarProdutoNoCarrinho($idBeneficio)) {
        $_SESSION['mensagem'] = ['texto' => 'Este produto não pode ser atualizado, pois já está no carrinho de um cliente.', 'tipo' => 'erro'];
    } else {
        if ($festa->atualizarBeneficio($idBeneficio, $nomeBeneficio, $descricaoBeneficio, $valorBeneficio, $quantidadeBeneficio, $tipoBeneficio)) {
            $_SESSION['mensagem'] = ['texto' => 'Produto atualizado com sucesso!', 'tipo' => 'sucesso'];
        } else {
            $_SESSION['mensagem'] = ['texto' => 'Erro ao atualizar produto.', 'tipo' => 'erro'];
        }
    }
    header("Location: beneficios.php?id_evento=$idEvento");
    exit;
}

// Função de exclusão de produto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['excluir_beneficio'])) {
    $idBeneficio = filter_input(INPUT_POST, 'id_produto', FILTER_VALIDATE_INT);

    if ($carrinho->verificarProdutoNoCarrinho($idBeneficio)) {
        $_SESSION['mensagem'] = ['texto' => 'Este produto não pode ser excluído, pois já está no carrinho de um cliente.', 'tipo' => 'erro'];
    } else {
        try {
            $queryExcluir = "DELETE FROM produto WHERE id_produto = :id_produto";
            $stmtExcluir = $connbanco->conectar()->prepare($queryExcluir);
            $stmtExcluir->bindParam(':id_produto', $idBeneficio, PDO::PARAM_INT);

            if ($stmtExcluir->execute()) {
                $_SESSION['mensagem'] = ['texto' => 'Produto excluído com sucesso!', 'tipo' => 'sucesso'];
            } else {
                $_SESSION['mensagem'] = ['texto' => 'Erro ao excluir Produto. Tente novamente.', 'tipo' => 'erro'];
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $_SESSION['mensagem'] = ['texto' => 'Erro ao excluir Produto.', 'tipo' => 'erro'];
        }
    }
    header("Location: beneficios.php?id_evento=$idEvento");
    exit;
}
?>
