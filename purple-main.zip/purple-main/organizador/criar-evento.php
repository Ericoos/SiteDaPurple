<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração do Evento</title>
    <link rel="stylesheet" href="form-festa.css">
    <link rel="stylesheet" href="../detalhesOrg/cabeçalho.css">
    <link rel="stylesheet" href="../detalhesOrg/rodape.css">
</head>
<script>
    document.addEventListener('DOMContentLoaded', () => {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
    }
});

function toggleDarkMode() {
    const body = document.body;
    body.classList.toggle('dark-mode');
    
    const isDarkMode = body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);

    // Alterar o link do CSS conforme a escolha
    const themeStylesheet = document.getElementById('themeStylesheet');
    if (isDarkMode) {
        themeStylesheet.setAttribute('href', 'festas_dark.css');
    } else {
        themeStylesheet.setAttribute('href', 'form-festa.css');
    }
}
    function formatarCEP(cep) {
        // Formatar o CEP para o padrão 00000-000
        cep.value = cep.value.replace(/\D/g, "").replace(/(\d{5})(\d)/, "$1-$2");
    }

    async function buscarEnderecoPorCEP() {
        const cep = document.getElementById('cep_evento').value.replace(/\D/g, ''); // Pega o valor do CEP e remove qualquer caractere não numérico
        const errorDiv = document.getElementById('erro_cep'); // Div para mostrar erros

        errorDiv.innerHTML = ''; // Limpar mensagens de erro

        if (cep.length === 8) { // Verifica se o CEP tem 8 caracteres
            try {
                // Faz a requisição para a API do ViaCEP
                const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
                const dados = await response.json();

                if (dados.erro) {
                    errorDiv.innerHTML = 'CEP não encontrado. Verifique o CEP digitado.';
                    errorDiv.style.color = 'red';
                    return;
                }

                // Preenche os campos com os dados retornados pela API
                document.getElementById('cep_evento').value = dados.cep || '';
                document.getElementById('rua_evento').value = dados.logradouro || '';
                document.getElementById('complemento_evento').value = dados.complemento || '';
                document.getElementById('bairro_evento').value = dados.bairro || '';
                document.getElementById('localidade_evento').value = dados.localidade || '';
                document.getElementById('estado_evento').value = dados.uf || '';
            } catch (error) {
                errorDiv.innerHTML = 'Erro ao buscar o CEP. Tente novamente.';
                errorDiv.style.color = 'red';
            }
        } else {
            errorDiv.innerHTML = 'Por favor, insira um CEP válido.';
            errorDiv.style.color = 'red';
        }
    }

    window.onload = function () {
        const dataEventoInput = document.querySelector('input[name="data_evento"]');
        const hoje = new Date();
        const ano = hoje.getFullYear();
        const mes = String(hoje.getMonth() + 1).padStart(2, '0');
        const dia = String(hoje.getDate()).padStart(2, '0');
        dataEventoInput.min = `${ano}-${mes}-${dia}`; // Define o mínimo de data possível como o dia de hoje
    };
</script>
<body>

    <header id="headerOrg"></header>

    <main class="configuracao">
    <form action="../bd/insert_evento.php" method="POST" enctype="multipart/form-data">
            <fieldset>
                <h1 class="textoh1" style="padding-top: 15px;">Informações Básicas</h1>
                <label for="nome_evento">Nome do evento:</label>
                <input type="text" id="event-name" name="nome_evento" placeholder="Insira nome do evento" required>

                <label for="descricao_evento">Descrição do evento:</label>
                <textarea style="font-family: Arial, sans-serif;" id="descricao_evento" name="descricao_evento" rows="4" placeholder="Insira a descrição do evento" required></textarea>

                <label for="tipo_evento">Tipo do evento:</label>
                    <select name="tipo_evento" required>
                        <option value="festa">Festa</option>
                        <option value="evento">Evento</option>
                        <option value="show">Show</option>
                    </select>


                <label for="banner">Banner do evento:</label>
                <input type="file" id="event-image" name="banner" required>

                <label for="data_evento">Data do Evento:</label>
                <input type="date" id="start-date" name="data_evento" required>

                <label for="hora_evento">Horário do Evento:</label>
                <input type="time" id="start-time" name="hora_evento" required>
            </fieldset>

            <fieldset>
                <h1> Local</h1>
                <label for="cep_evento">CEP do Evento:</label>
                <input type="text" id="cep_evento" name="cep_evento" maxlength="9" oninput="formatarCEP(this); buscarEnderecoPorCEP()" required placeholder="00000-000">
                <div id="erro_cep"></div>

                <label for="rua_evento">Rua/Avenida:</label>
                <input type="text" id="rua_evento" name="rua_evento" readonly>

                <label for="complemento_evento">Complemento:</label>
                <input type="text" id="complemento_evento" name="complemento_evento">

                <label for="bairro_evento">Bairro</label>
                <input type="text" id="bairro_evento" name="bairro_evento" readonly>

                <label for="localidade_evento">Localidade:</label>
                <input type="text" id="localidade_evento" name="localidade_evento" readonly>

                <label for="estado_evento">Estado:</label>
                <input type="text" id="estado_evento" name="estado_evento" readonly>
            </fieldset>

            <fieldset>
                <h1>Responsabilidades</h1>
                <p>Ao publicar este evento, estou de acordo com os Termos de uso, com as Diretrizes de Comunidade e com o Acordo de Processamento de Dados, bem como declaro estar ciente da Política de Privacidade, da Política de Cookies e das Obrigatoriedades Legais.</p>
            </fieldset>

            <button type="submit">Enviar</button>
            <a class="buttonvoltar" href="../organizador/festas.php">Voltar</a>
        </form>
    </main>

    <script>
        fetch('../detalhesOrg/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('headerOrg').innerHTML = data;
            });

        let menuVisible = false;

        function toggleMenu() {
            const menu = document.querySelector('.dropdown-menu');
            menuVisible = !menuVisible;
            menu.style.display = menuVisible ? 'block' : 'none';
        }

        document.addEventListener('click', function (event) {
            const menu = document.querySelector('.dropdown-menu');
            const menuButton = document.querySelector('.menu-icon');

            if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
                menuVisible = false;
                menu.style.display = 'none';
            }
        });
    </script>

</body>
</html>
