<?php
session_start();
include_once('../bd/conexao.php');
include_once('../bd/festa.php');

$connbanco = new banco();
$connbanco->conectar();

if (isset($_SESSION['organizadores'])) {
    $userIdOrg = $_SESSION['organizadores']['id_loginOrg'];
} else {
    echo "Não foi encontrado usuário!";
    exit;
}

// Captura o ID do evento via GET ou sessão
if (isset($_GET['id_evento'])) {
    $id_evento = $_GET['id_evento'];
    $_SESSION['id_evento'] = $id_evento; // Armazena na sessão para acessos subsequentes
} elseif (isset($_SESSION['id_evento'])) {
    $id_evento = $_SESSION['id_evento'];
} else {
    echo "ID do evento não encontrado!";
    exit;
}

if (!$id_evento) {
    echo "ID do evento não foi fornecido!";
    exit;
}

if ($connbanco) {
    $festa = new Festa();
    $evento = $festa->buscarEventoPorId($id_evento);

    if (!$evento) {
        echo "Evento não encontrado!";
        exit;
    }
}

// Lógica para adicionar ou atualizar os dados do evento
if (isset($_POST['atualizar'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nomeEventoNovo = $_POST['nome_evento'];
        $descricaoEventoNova = $_POST['descricao_evento'];
        $dataEventoNova = $_POST['data_evento'];
        $horaEventoNova = $_POST['hora_evento'];
        $cepEventoNovo = $_POST['cep_evento'];
        $ruaEventoNova = $_POST['rua_evento'];
        $complementoEventoNovo = $_POST['complemento_evento'];
        $estadoEventoNovo = $_POST['estado_evento'];

        // Verifica se o banner foi enviado para upload
        $bannerNovo = isset($_FILES['banner']['name']) && $_FILES['banner']['name'] !== '' ? $_FILES['banner']['name'] : $evento['banner'];

        // Verificação e upload do banner
        if (isset($_FILES['banner']) && $_FILES['banner']['error'] === UPLOAD_ERR_OK) {
            $extensao = pathinfo($_FILES['banner']['name'], PATHINFO_EXTENSION);
            $extensoesPermitidas = ['jpg', 'jpeg', 'png'];
            if (in_array($extensao, $extensoesPermitidas)) {
                $destino = '../imagens/banners/' . basename($_FILES['banner']['name']);
                move_uploaded_file($_FILES['banner']['tmp_name'], $destino);
            } else {
                echo "Formato de banner inválido. Aceitamos apenas .jpg, .jpeg e .png.";
                exit;
            }
        }

        // Atualizando dados do evento
        $result = $festa->atualizaDadosFesta(
            $userIdOrg,
            $id_evento,
            $nomeEventoNovo,
            $descricaoEventoNova,
            $dataEventoNova,
            $horaEventoNova,
            $cepEventoNovo,
            $ruaEventoNova,
            $complementoEventoNovo,
            $estadoEventoNovo,
            $bannerNovo
        );

        if ($result) {
            header("Location: detalhes.php?id_evento=$id_evento");
            exit();
        }
    }
}

// Buscando os produtos da festa
$produtos = $festa->buscarProdutosPorIdEvento($id_evento);

// Calculando o lucro estimado
$lucroIngressos = 0;
$lucroProdutos = 0;
$totalIngressos = 0;

foreach ($produtos as $produto) {
    $lucroProdutos += $produto['valor'] * $produto['quantidade'];
    if ($produto['tipo'] === 'ingresso') {
        $totalIngressos += $produto['quantidade'];
    }
}

$totalLucro = $lucroIngressos + $lucroProdutos;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="detalhes.css">
    <link rel="stylesheet" href="../detalhesOrg/cabeçalho.css">
    <link rel="stylesheet" href="../detalhesOrg/rodape.css">
    <title>Edição do Evento</title>
</head>
<script>
    document.addEventListener('DOMContentLoaded', () => {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
    }
});

function toggleDarkMode() {
    const body = document.body;
    body.classList.toggle('dark-mode');
    
    const isDarkMode = body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);

    // Alterar o link do CSS conforme a escolha
    const themeStylesheet = document.getElementById('themeStylesheet');
    if (isDarkMode) {
        themeStylesheet.setAttribute('href', 'festas_dark.css');
    } else {
        themeStylesheet.setAttribute('href', 'form-festa.css');
    }
}

    function formatarCEP(cep) {
        // Formatar o CEP para o padrão 00000-000
        cep.value = cep.value.replace(/\D/g, "").replace(/(\d{5})(\d)/, "$1-$2");
    }

    async function buscarEnderecoPorCEP() {
        const cep = document.getElementById('cep_evento').value.replace(/\D/g, ''); // Pega o valor do CEP e remove qualquer caractere não numérico
        const errorDiv = document.getElementById('erro_cep'); // Div para mostrar erros

        errorDiv.innerHTML = ''; // Limpar mensagens de erro

        if (cep.length === 8) { // Verifica se o CEP tem 8 caracteres
            try {
                // Faz a requisição para a API do ViaCEP
                const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
                const dados = await response.json();

                if (dados.erro) {
                    errorDiv.innerHTML = 'CEP não encontrado. Verifique o CEP digitado.';
                    errorDiv.style.color = 'red';
                    return;
                }

                // Preenche os campos com os dados retornados pela API
                document.getElementById('cep_evento').value = dados.cep || '';
                document.getElementById('rua_evento').value = dados.logradouro || '';
                document.getElementById('complemento_evento').value = dados.complemento || '';
                document.getElementById('bairro_evento').value = dados.bairro || '';
                document.getElementById('localidade_evento').value = dados.localidade || '';
                document.getElementById('estado_evento').value = dados.uf || '';
            } catch (error) {
                errorDiv.innerHTML = 'Erro ao buscar o CEP. Tente novamente.';
                errorDiv.style.color = 'red';
            }
        } else {
            errorDiv.innerHTML = 'Por favor, insira um CEP válido.';
            errorDiv.style.color = 'red';
        }
    }

    window.onload = function () {
        const dataEventoInput = document.querySelector('input[name="data_evento"]');
        const hoje = new Date();
        const ano = hoje.getFullYear();
        const mes = String(hoje.getMonth() + 1).padStart(2, '0');
        const dia = String(hoje.getDate()).padStart(2, '0');
        dataEventoInput.min = `${ano}-${mes}-${dia}`; // Define o mínimo de data possível como o dia de hoje
    };
</script>

<body>
    <header id="headerOrg"></header>

    <main class="configuracao">
        <form action="" method="POST" enctype="multipart/form-data">
            <fieldset>
                <h1 class="textoh1" style="padding-top: 15px;">Edição de evento</h1>
                <label for="event-name">Novo nome do evento:</label>
                <input type="text" id="event-name" name="nome_evento" value="<?php echo htmlspecialchars($evento['nome_evento']); ?>" required>

                <label for="descricao-casa">Nova descrição do evento:</label>
                <textarea style="font-family: Arial, sans-serif;" id="descricao-casa" name="descricao_evento" rows="4" required><?php echo htmlspecialchars($evento['descricao_evento']); ?></textarea>

                <label for="event-image">Modificar imagem de divulgação:</label>
                <!-- Não traz o banner atual se não for necessário -->
                <input type="file" id="event-image" name="banner">

                <label for="start-date">Modificar data do evento:</label>
                <input type="date" id="start-date" name="data_evento" value="<?php echo $evento['data_evento']; ?>" required>

                <label for="start-time">Modificar horário de íncio:</label>
                <input type="time" id="start-time" name="hora_evento" value="<?php echo $evento['hora_evento']; ?>" required>
            </fieldset>

            <fieldset>
                <h1>2. Local</h1>
                <label for="cep_evento">CEP do Evento:</label>
                <input type="text" id="cep_evento" name="cep_evento" value="<?php echo htmlspecialchars($evento['cep_evento']); ?>" maxlength="9" oninput="formatarCEP(this); buscarEnderecoPorCEP()" required placeholder="00000-000">
                <div id="erro_cep"></div>
        

                <label for="address">Rua/Avenida:</label>
                <input type="text" id="address" name="rua_evento" value="<?php echo htmlspecialchars($evento['rua_evento']); ?>" required>

                <label for="number">Complemento:</label>
                <input type="text" id="number" name="complemento_evento" value="<?php echo htmlspecialchars($evento['complemento_evento']); ?>" required>

                <label for="city">Bairro:</label>
                <input type="text" id="city" name="bairro_evento" value="<?php echo htmlspecialchars($evento['bairro_evento']); ?>" readonly>

                <label for="city">Localidade:</label>
                <input type="text" id="city" name="localidade_evento" value="<?php echo htmlspecialchars($evento['localidade_evento']); ?>" readonly>

                <label for="city">Estado:</label>
                <input type="text" id="city" name="estado_evento" value="<?php echo htmlspecialchars($evento['estado_evento']); ?>" readonly>
                
            </fieldset>

            <fieldset>
                <h1>3. Produtos Associados</h1>
                <ul>
                    <?php if ($produtos): ?>
                        <?php foreach ($produtos as $produto): ?>
                            <li>
                                <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                                <p>Quantidade inicial: <?php echo $produto['quantidade']; ?></p>
                                <p>Quantidade disponível: <?php echo $produto['quantidade_pfesta']; ?></p>
                                <hr>
                            </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Não há produtos associados a este evento.</p>
                    <?php endif; ?>
                </ul>
            </fieldset>

            <button type="submit" name="atualizar">Enviar</button>
            <a class="buttonvoltar" href="../organizador/festas.php">Voltar</a>
            <a class="buttonvoltar" href="../organizador/beneficios.php">Área de produtos</a>
        </form>
    </main>
    <footer id="footerOrg"></footer>
    <script>
        fetch('../detalhesOrg/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('headerOrg').innerHTML = data;
            });

        fetch('../detalhesOrg/rodape.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footerOrg').innerHTML = data;
            });

        let menuVisible = false;

        function toggleMenu() {
            const menu = document.querySelector('.dropdown-menu');
            menuVisible = !menuVisible;
            menu.style.display = menuVisible ? 'block' : 'none';
        }

        document.addEventListener('click', function(event) {
            const menu = document.querySelector('.dropdown-menu');
            const menuButton = document.querySelector('.menu-icon');

            if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
                menuVisible = false;
                menu.style.display = 'none';
            }
        });
    </script>
</body>
</html>
