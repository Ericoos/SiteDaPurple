<?php
include_once('../bd/organizador.php');
session_start();

// Verificando se o organizador está logado
if (isset($_SESSION['organizadores'])) {
    $id_loginOrg = $_SESSION['organizadores'];
} else {
    echo "Organizador não encontrado!";
    exit;
}

$dados = new Organizador();
$organizador = $dados->pegaDadosOrg($id_loginOrg['id_loginOrg']);

if (!$organizador) {
    echo "Organizador não encontrado!";
    exit;
}

$nome_organizador = $organizador["nome_organizador"];
$email_contato = $organizador["email_contato"];
$email_organizador = $organizador["email_organizador"];
$descricao_organizador = $organizador["descricao_organizador"];
$telefone = $organizador['telefone_organizador'];
$chave_pix = $organizador['chave_pix'];
$senha = $organizador['senha_organizador'];

// Lógica para atualizar os dados do organizador
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nomeNovo = $_POST['nome_organizador'];
    $emailNovo = $_POST['email_contato'];
    $email_organizadorNovo = $_POST['email_organizador'];
    $descricao_organizadorNovo = $_POST['descricao_organizador'];
    $telefoneNovo = $_POST['telefone_organizador'];
    $chave_pixNovo = $_POST['chave_pix'];
    $senhaNova = isset($_POST['senha_organizador']) ? $_POST['senha_organizador'] : null;

    $result = $dados->atualizarPerfilOrganizador($id_loginOrg['id_loginOrg'], $nomeNovo, $emailNovo, $email_organizadorNovo, $descricao_organizadorNovo, $telefoneNovo, $chave_pixNovo, $senhaNova);

    if ($result) {
        header("Location: editar-perfil.php");
        exit();
    }
    if ($result) {
        $_SESSION['mensagem'] = ['texto' => 'Produto excluído com sucesso!', 'tipo' => 'sucesso'];
    } else {
        $_SESSION['mensagem'] = ['texto' => 'Erro ao excluir Produto. Tente novamente.', 'tipo' => 'erro'];
    }
}

$mensagem = isset($_SESSION['mensagem']) ? $_SESSION['mensagem'] : null;
unset($_SESSION['mensagem']); // Limpa a mensagem após exibição
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração</title>
    <link rel="stylesheet" href="configuracao.css">
    <link rel="stylesheet" href="../detalhesOrg/cabeçalho.css">
    <link rel="stylesheet" href="../detalhesOrg/rodape.css">
</head>

<body>

    <header id="headerOrg"></header>

    <main class="configuracao">

    <form action="editar-perfil.php" method="POST" enctype="multipart/form-data">
    <fieldset>
        <h1 style="padding-top: 15px;">Editar Perfil</h1>

        <?php if ($mensagem): ?>
            <div class="<?php echo $mensagem['tipo'] === 'sucesso' ? 'success-message' : 'error-message'; ?>">
                <?php echo htmlspecialchars($mensagem['texto']); ?>
            </div>
        <?php endif; ?>
        
        <label for="nome-perfil">Nome:</label>
        <input type="text" id="nome-perfil" name="nome_organizador" value="<?php echo htmlspecialchars($nome_organizador); ?>" required>

        <label for="email-perfil">E-mail Contato:</label>
        <input type="email" id="email-perfil" name="email_contato" value="<?php echo htmlspecialchars($email_contato); ?>" required>

        <label for="email-perfil">E-mail para Login:</label>
        <input type="email" id="email-perfil" name="email_organizador" value="<?php echo htmlspecialchars($email_organizador); ?>" required>

        <nav>
            <div class="telefone-txt">
                <label for="telefone-perfil">Telefone:</label>
            </div>
            <div class="telefone">
                <input 
                    placeholder="(00) 00000-0000" 
                    name="telefone_organizador" 
                    required 
                    type="tel" 
                    id="telefone-perfil" 
                    maxlength="15" 
                    value="<?php echo htmlspecialchars($telefone); ?>" 
                    oninput="formatarTelefone(this)">
            </div>
        </nav>

        <label for="chave_pix">Chave Pix:</label>
        <input type="text" id="chave_pix" name="chave_pix" value="<?php echo htmlspecialchars($chave_pix); ?>" required>

        <label for="senha-perfil">Nova Senha:</label>
        <input type="password" id="senha-perfil" name="senha_organizador" placeholder="Digite a nova senha">

        <!-- Novo campo de descrição -->
        <label for="descricao-perfil">Descrição:</label>
        <textarea id="descricao_organizador" name="descricao_organizador" rows="4" cols="50"><?php echo htmlspecialchars($descricao_organizador); ?></textarea>

        <!-- Novo campo de imagem -->
        <label for="imagem_perfil">Imagem de Perfil:</label>
        <input type="file" id="imagem_perfil" name="imagem_perfil" accept="image/*">

        <button class="botaoacao" type="submit">Atualizar Perfil</button>
        <a class="buttonvoltar" href="../organizador/festas.php">Voltar</a>
    </fieldset>
</form>

    </main>

    <footer id="footerOrg"></footer>

    <script>
        fetch('../detalhesOrg/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('headerOrg').innerHTML = data;
            });

        fetch('../detalhesOrg/rodape.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footerOrg').innerHTML = data;
            });

        let menuVisible = false;

        function toggleMenu() {
            const menu = document.querySelector('.dropdown-menu');
            menuVisible = !menuVisible;
            menu.style.display = menuVisible ? 'block' : 'none';
        }

        document.addEventListener('click', function(event) {
            const menu = document.querySelector('.dropdown-menu');
            const menuButton = document.querySelector('.menu-icon');

            if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
                menuVisible = false;
                menu.style.display = 'none';
            }
        });
    </script>

</body>
</html>
