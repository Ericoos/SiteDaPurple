<?php

include_once('../bd/conexao.php');
include_once('../bd/festa.php');
include_once('../organizador/backendbeneficios.php');
include_once('../bd/carrinho.php'); // Incluindo o arquivo Carrinho

$connbanco = new banco();
$connbanco->conectar();

$mensagem = isset($_SESSION['mensagem']) ? $_SESSION['mensagem'] : null;
unset($_SESSION['mensagem']); // Limpa a mensagem após exibição

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área do Organizador</title>
    <link rel="stylesheet" href="areaBeneficios.css">
    <link rel="stylesheet" href="../detalhesOrg/cabeçalho.css">
    <link rel="stylesheet" href="../detalhesOrg/rodape.css">
    <style>
        .success-message {
            color: green;
            background: #d4edda;
            border: 1px solid #c3e6cb;
            padding: 10px;
            margin-bottom: 15px;
        }

        .error-message {
            color: red;
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 10px;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <header id="headerOrg"></header>

    <main class="organizador">
        <?php if ($mensagem): ?>
            <div class="<?php echo $mensagem['tipo'] === 'sucesso' ? 'success-message' : 'error-message'; ?>">
                <?php echo htmlspecialchars($mensagem['texto']); ?>
            </div>
        <?php endif; ?>

        <form action="beneficios.php" method="POST">
            <input type="hidden" name="id_evento" value="<?php echo htmlspecialchars($idEvento); ?>">
            <div>
                <fieldset>
                    <h1 style="padding-top: 15px;">Criar produto</h1>
                    <input type="hidden" name="id_evento" value="<?php echo htmlspecialchars($idEvento); ?>">

                    <label for="nome">Nome do produto:</label>
                    <input type="text" name="nome" placeholder="Insira um nome" required>

                    <label for="descricao">Descrição do produto:</label>
                    <textarea name="descricao" rows="4" placeholder="Insira a descrição do seu produto" required></textarea>

                    <label for="valor">Valor do produto:</label>
                    <input type="number" name="valor" placeholder="00,00 R$" required>

                    <label for="quantidade">Quantidade do produto:</label>
                    <input type="number" name="quantidade" placeholder="Insira a quantidade" required>

                    <label for="tipo">Tipo do produto:</label>
                    <select name="tipo" required>
                        <option value="beneficio">Benefício</option>
                        <option value="ingresso">Ingresso</option>
                    </select>

                    <button class="botaoacao" type="submit" name="adicionar_beneficio">Adicionar</button>
                    <a class="buttonvoltar" href="../organizador/festas.php">Voltar</a>
                </fieldset>
            </div>
        </form>
    </main>

    <main class="organizador">
        <fieldset>
            <h1 style="padding-top: 15px;">Atualizar produtos</h1>
        </fieldset>

        <div class="ingresso-carrosel" id="carrossel">
            <?php
            // Instanciar a classe Carrinho
            $carrinho = new Carrinho();

            if ($beneficios) {
                foreach ($beneficios as $beneficio) {
                    $produtoNoCarrinho = $carrinho->verificarProdutoNoCarrinho($beneficio['id_produto']); // Verifica se o produto está no carrinho
                    echo "<div class='ingresso-card'>
                        <form method='POST' action='beneficios.php'>
                            <input type='hidden' name='id_evento' value='{$idEvento}' />
                            <input type='hidden' name='id_produto' value='{$beneficio['id_produto']}' />
                            <fieldset>
                                <label for='nome'>Nome do produto:</label>
                                <input type='text' name='nome' value='" . htmlspecialchars($beneficio['nome']) . "' required " . ($produtoNoCarrinho ? "disabled" : "") . ">

                                <label for='descricao'>Descrição do produto:</label>
                                <textarea name='descricao' required " . ($produtoNoCarrinho ? "disabled" : "") . ">" . htmlspecialchars($beneficio['descricao']) . "</textarea>

                                <label for='valor'>Valor do produto:</label>
                                <input type='number' name='valor' value='" . htmlspecialchars($beneficio['valor']) . "' required " . ($produtoNoCarrinho ? "disabled" : "") . ">

                                <label for='quantidade'>Quantidade:</label>
                                <input type='number' name='quantidade' value='" . htmlspecialchars($beneficio['quantidade']) . "' required " . ($produtoNoCarrinho ? "disabled" : "") . ">

                                <label for='tipo'>Tipo do produto:</label>
                                <select name='tipo' " . ($produtoNoCarrinho ? "disabled" : "") . ">
                                    <option value='beneficio'" . ($beneficio['tipo'] === 'beneficio' ? ' selected' : '') . ">Benefício</option>
                                    <option value='ingresso'" . ($beneficio['tipo'] === 'ingresso' ? ' selected' : '') . ">Ingresso</option>
                                </select>";

                    if ($produtoNoCarrinho) {
                        echo "<p>Produto ativo - Não pode ser alterado ou excluído.</p>";
                    } else {
                        echo "
                            <button class='botaoacaoBeneficio' type='submit' name='editar_beneficio'>Atualizar</button>
                            <button class='botaoacaoBeneficio excluir-btn' type='submit' name='excluir_beneficio'>Excluir</button>";
                    }

                    echo "</fieldset>
                        </form>
                    </div>";
                }
            } else {
                echo "<p>Nenhum produto encontrado.</p>";
            }
            ?>
        </div>

        <div class="navegacao-carrossel">
            <button id="prevButton" class="botao-carrossel">Anterior</button>
            <span class="pagina-atual" id="pagina-atual">Página 1</span>
            <button id="nextButton" class="botao-carrossel">Próximo</button>
        </div>
    </main>

    <footer id="footerOrg"></footer>

    <script src="paginacaoArea.js"></script>
    <script src="popup.js"></script>
    <script>
        fetch('../detalhesOrg/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('headerOrg').innerHTML = data;
            });

        fetch('../detalhesOrg/rodape.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footerOrg').innerHTML = data;
            });

        let menuVisible = false;

        function toggleMenu() {
            const menu = document.querySelector('.dropdown-menu');
            menuVisible = !menuVisible;
            menu.style.display = menuVisible ? 'block' : 'none';
        }

        document.addEventListener('click', function(event) {
            const menu = document.querySelector('.dropdown-menu');
            const menuButton = document.querySelector('.menu-icon');

            if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
                menuVisible = false;
                menu.style.display = 'none';
            }
        });
    </script>
</body>

</html>
