<?php
session_start();
include_once('../bd/conexao.php');
include_once('../bd/festa.php');

$connbanco = new banco();
$connbanco->conectar();

if (isset($_SESSION['organizadores'])) {
    $userIdOrg = $_SESSION['organizadores']['id_loginOrg'];
} else {
    echo "Não foi encontrado usuário!";
    exit;
}

$tipoEvento = isset($_GET['tipo_evento']) ? $_GET['tipo_evento'] : 'ativo'; // Por padrão, filtra eventos ativos

if ($connbanco) {
    $festa = new Festa();
    $festas = $festa->buscarEventos($userIdOrg, $tipoEvento);
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área do Organizador</title>
    <link rel="stylesheet" href="festas.css">
    <link rel="stylesheet" href="../detalhesOrg/cabeçalho.css">
    <link rel="stylesheet" href="../detalhesOrg/rodape.css">
</head>

<body>
    <header id="headerOrg"></header>

    <main class="organizador">
        <div class="background-cards">
            <section class="dashboard">
                <h1>Seus Eventos</h1>

                <!-- Formulário de filtro de eventos -->
                <form method="GET" action="festas.php">
                    <label for="tipo_evento">Escolha o tipo de evento:</label>
                    <select name="tipo_evento" id="tipo_evento" onchange="this.form.submit()">
                        <option value="ativo" <?= $tipoEvento == 'ativo' ? 'selected' : ''; ?>>Ativos</option>
                        <option value="inativo" <?= $tipoEvento == 'inativo' ? 'selected' : ''; ?>>Inativos</option>
                    </select>
                </form>

                <!-- Se não houver festas, exibe uma mensagem de erro -->
                <?php if (empty($festas)): ?>
                    <div class="alerta-erro">
                        <p><strong>Atenção:</strong> Você ainda não criou nenhuma festa. Crie um evento para poder gerenciá-lo.</p>
                    </div>
                <?php endif; ?>

                <!-- Exibindo as festas -->
                <div class="ingresso-carrosel">
                    <?php
                    if ($festas) {
                        foreach ($festas as $festa) {
                            $dataEvento = strtotime($festa['data_evento']);
                            $dataAtual = strtotime(date('Y-m-d'));

                            // Filtra os eventos com base na escolha do usuário
                            if (($tipoEvento == 'ativo' && $dataEvento >= $dataAtual) || ($tipoEvento == 'inativo' && $dataEvento < $dataAtual)) {
                                echo "<div class='ingresso-card'>";
                                $bannerPath = "../imagens/banners/" . htmlspecialchars($festa['banner']);
                                echo "<img src='$bannerPath' alt='Imagem do Evento' class='imagem-festa'>";

                                echo "<div class='ingresso-info'>";
                                echo "<h2>" . htmlspecialchars($festa['nome_evento']) . "</h2>";
                                echo "<h3>Data: " . date('d/m/Y', strtotime($festa['data_evento'])) . "</h3>";
                                echo "</div>";

                                // Verifica se o evento é ativo ou inativo
                                $eventoAtivo = $dataEvento >= $dataAtual;

                                if ($eventoAtivo) {
                                    // Se for ativo, permite editar o evento
                                    echo "<form action='detalhes.php' method='GET' class='button-form'>
                                        <input type='hidden' name='id_evento' value='" . htmlspecialchars($festa['id_evento']) . "'>
                                        <button class='ver-ingresso'>Editar evento</button>
                                      </form>";
                                    echo "<form action='beneficios.php' method='GET' class='button-form'>
                                        <input type='hidden' name='id_evento' value='" . htmlspecialchars($festa['id_evento']) . "'>
                                        <button class='ver-ingresso'>Editar produtos</button>
                                      </form>";
                                } else {

                                    echo "<form class='button-form'>
                                            <button class='ver-ingressocancelado' disabled>Evento Inativo</button>
                                          </form>";
                                    echo "<form action='beneficios.php' method='GET' class='button-form'>
                                        <input type='hidden' name='id_evento' value='" . htmlspecialchars($festa['id_evento']) . "'>
                                        <button class='ver-ingresso'>Visualizar Produtos</button>
                                      </form>";
                                }

                                echo "<form action='gerenciamento.php' method='GET' class='button-form'>
                                        <input type='hidden' name='id_evento' value='" . htmlspecialchars($festa['id_evento']) . "'>
                                        <button class='ver-ingresso'>Listagem</button>
                                      </form>";

                                echo "</div>";
                            }
                        }
                    }
                    ?>
                </div>
            </section>

            <div class="navegacao-carrossel">
                <button id="prevButton" class="botao-carrossel">Anterior</button>
                <span id="paginaAtual" class="pagina-atual">Página 1</span>
                <button id="nextButton" class="botao-carrossel">Próximo</button>
            </div>
        </div>
    </main>

    <main class="organizador">
        <section class="actions-section">
            <h1>Ações Rápidas</h1>
            <div class="actions-grid">
                <div class="action-card">
                    <h3>Criar Evento</h3>
                    <p>Configure um novo evento e comece a vender ingressos.</p>
                    <a href="../organizador/criar-evento.php">
                        <button class="botaoacao">Começar</button>
                    </a>
                </div>

                <div class="action-card">
                    <h3>Configurações</h3>
                    <p>Personalize sua conta e preferências.</p>
                    <a href="../organizador/editar-perfil.php">
                        <button class="botaoacao">Alterar</button>
                    </a>
                </div>
            </div>
        </section>
    </main>

    <footer id="footerOrg"></footer>

    <script src="paginacao.js"></script>

    <script>
        fetch('../detalhesOrg/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('headerOrg').innerHTML = data;
            });

        fetch('../detalhesOrg/rodape.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footerOrg').innerHTML = data;
            });

        let menuVisible = false;

        function toggleMenu() {
            const menu = document.querySelector('.dropdown-menu');
            menuVisible = !menuVisible;
            menu.style.display = menuVisible ? 'block' : 'none';
        }

        document.addEventListener('click', function(event) {
            const menu = document.querySelector('.dropdown-menu');
            const menuButton = document.querySelector('.menu-icon');

            if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
                menuVisible = false;
                menu.style.display = 'none';
            }
        });
    </script>

</body>

</html>
