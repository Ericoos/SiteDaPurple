document.addEventListener("DOMContentLoaded", () => {
  const carouselContainer = document.querySelector(".ingresso-carrosel");
  const cards = document.querySelectorAll(".ingresso-card");
  const maxCardsPerPage = 3;
  const pageIndicator = document.querySelector("#paginaAtual");
  let currentPage = 0;

  const prevButton = document.querySelector("#prevButton");
  const nextButton = document.querySelector("#nextButton");

  function updateCarousel() {
      const start = currentPage * maxCardsPerPage;
      const end = start + maxCardsPerPage;

      cards.forEach((card, index) => {
          card.style.display = index >= start && index < end ? "block" : "none";
      });

      const visibleCount = Math.min(cards.length - start, maxCardsPerPage);
      carouselContainer.style.gridTemplateColumns = `repeat(${visibleCount}, 1fr)`;

      prevButton.disabled = currentPage === 0;
      nextButton.disabled = end >= cards.length;

      pageIndicator.textContent = `Página ${currentPage + 1}`;
  }

  prevButton.addEventListener("click", () => {
      if (currentPage > 0) {
          currentPage--;
          updateCarousel();
      }
  });

  nextButton.addEventListener("click", () => {
      if ((currentPage + 1) * maxCardsPerPage < cards.length) {
          currentPage++;
          updateCarousel();
      }
  });

  updateCarousel();
});
