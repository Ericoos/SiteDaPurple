<?php
session_start();
include_once('../bd/conexao.php');
include_once('../bd/festa.php');

// Verifica se o organizador está logado
if (!isset($_SESSION['organizadores'])) {
    echo "Não foi encontrado usuário!";
    exit;
}

// Verifica se o ID do evento foi fornecido
if (isset($_GET['id_evento'])) {
    $id_evento = $_GET['id_evento'];
} else {
    echo "ID do evento não fornecido!";
    exit;
}

$connbanco = new banco();
$conn = $connbanco->conectar();

$id_cadastro = $_SESSION['organizadores']['id_loginOrg'];

$festa = new Festa();
$evento = $festa->buscarEventoPorId($id_evento);

// Verifica se o evento pertence ao organizador
if (!$evento || $evento['id_loginOrg'] != $id_cadastro) {
    echo "Evento não encontrado ou você não tem permissão para gerenciá-lo.";
    exit;
}

// Consulta para obter os participantes do evento a partir da tabela carrinho_produtos
$queryParticipantes = "
    SELECT 
        p.id_pagamento, 
        p.nome_pagamento, 
        p.email_pagamento, 
        p.telefone_pagamento, 
        pp.id_carrinhoProd, 
        pp.id_produto, 
        pp.quantidade_produtos, 
        p.valor_totalpag AS valor_total, -- Alterado para puxar valor_totalpag da tabela pagamento
        pr.nome AS produto_nome
    FROM carrinho_produtos pp
    JOIN pagamento p ON pp.id_carrinhoProd = p.id_carrinhoProd
    JOIN produto pr ON pp.id_produto = pr.id_produto
    WHERE p.id_evento = :id_evento
";

$stmt = $conn->prepare($queryParticipantes);
$stmt->bindParam(':id_evento', $id_evento, PDO::PARAM_INT);
$stmt->execute();

$participantes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calcula faturamento total e quantidade total de ingressos vendidos
$faturamentoTotal = 0;
$produtosVendidos = 0;

foreach ($participantes as $participante) {
    $faturamentoTotal += $participante['valor_total'];
    $produtosVendidos += $participante['quantidade_produtos'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área do Organizador</title>
    <link rel="stylesheet" href="gerenciamento.css">
    <link rel="stylesheet" href="../detalhesOrg/cabeçalho.css">
    <link rel="stylesheet" href="../detalhesOrg/rodape.css">
</head>

<body>
    <header id="headerOrg"></header>

    <main class="organizador">
        <section class="actions-section">
            <h1>Informações</h1>
            <div class="actions-grid">
                <div class="action-card">
                    <h1>Faturamento Total:</h1>
                    <h3><?= 'R$ ' . number_format($faturamentoTotal, 2, ',', '.'); ?></h3>
                </div>

                <div class="action-card">
                    <h1>Produtos Vendidos:</h1>
                    <h3><?= $produtosVendidos; ?></h3>
                </div>

                <div class="action-card">
                    <h1>Participantes:</h1>
                    <h3><?= count($participantes); ?></h3>
                </div>
            </div>

            <a class="buttonvoltar" href="../organizador/festas.php">Voltar</a>
        </section>
    </main>

    <main class="organizador">
        <div class="background-cards">
            <section class="dashboard">
                <h1>Gerenciamento de Clientes</h1>

                <div class="clientes-filtro">
                    <input type="text" id="searchInput" placeholder="Pesquisar cliente..." onkeyup="filtrarClientes()">
                </div>

                <div class="centralizar">
                    <div class="clientes-carrossel">
                        <table class="clientes-tabela">
                            <thead>
                                <tr>
                                    <th>ID Pagamento</th>
                                    <th>Nome</th>
                                    <th>Email</th>
                                    <th>Telefone</th>
                                    <th>Produto</th>
                                    <th>Quantidade</th>
                                    <th>Valor Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($participantes): ?>
                                    <?php foreach ($participantes as $participante): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($participante['id_pagamento']); ?></td>
                                            <td><?= htmlspecialchars($participante['nome_pagamento']); ?></td>
                                            <td><?= htmlspecialchars($participante['email_pagamento']); ?></td>
                                            <td><?= htmlspecialchars($participante['telefone_pagamento']); ?></td>
                                            <td><?= htmlspecialchars($participante['produto_nome']); ?></td>
                                            <td><?= htmlspecialchars($participante['quantidade_produtos']); ?></td>
                                            <td><?= 'R$ ' . number_format($participante['valor_total'], 2, ',', '.'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7">Nenhum participante encontrado para este evento.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="navegacao-carrossel">
                    <button id="prevButton" class="botao-carrossel">Anterior</button>
                    <span id="paginaAtual" class="pagina-atual">Página 1</span>
                    <button id="nextButton" class="botao-carrossel">Próximo</button>
                </div>
            </section>
        </div>
    </main>

    <footer id="footerOrg"></footer>

    <script src="paginacaoGerenciamento.js"></script>

    <script>
        fetch('../detalhesOrg/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('headerOrg').innerHTML = data;
            });

        fetch('../detalhesOrg/rodape.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footerOrg').innerHTML = data;
            });

        let menuVisible = false;

        function toggleMenu() {
            const menu = document.querySelector('.dropdown-menu');
            menuVisible = !menuVisible;
            menu.style.display = menuVisible ? 'block' : 'none';
        }

        document.addEventListener('click', function(event) {
            const menu = document.querySelector('.dropdown-menu');
            const menuButton = document.querySelector('.menu-icon');

            if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
                menuVisible = false;
                menu.style.display = 'none';
            }
        });
    </script>
</body>

</html>
