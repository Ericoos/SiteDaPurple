<?php
session_start();
include('../bd/verificaLogin.php');  

if (!isset($_SESSION['organizadores'])) {
    header('Location: ../login/login.php'); 
    exit();
}

$nomeOrganizador = $_SESSION['organizadores']['nome_organizador'];

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Organizador</title>
</head>
<body>
    <h1>Olá, <?php echo $nomeOrganizador; ?></h1>

    <nav>
        <ul>
            <li><a href="perfil-organizador.php">Editar Usuário</a></li>
            <li><a href="criar-evento.php">Criar Evento</a></li>
            <li><a href="festas.php">Visualizar seus eventos</a></li>
        </ul>
    </nav>
</body>
</html>
