<?php
include_once('../bd/organizador.php');
session_start();

// Verificando se o organizador está logado
if (isset($_SESSION['organizadores'])) {
    $id_loginOrg = $_SESSION['organizadores'];
} else {
    echo "Organizador não encontrado!";
    exit;
}

$dados = new Organizador();
$organizador = $dados->pegaDadosOrg($id_loginOrg['id_loginOrg']);

if (!$organizador) {
    echo "Organizador não encontrado!";
    exit;
}

$nome_organizador = $organizador["nome_organizador"];
$email_contato = $organizador["email_contato"];
$imagem_perfil = $organizador["imagem_perfil"];
$email_organizador = $organizador["email_organizador"];
$telefone = $organizador['telefone_organizador'];
$chave_pix = $organizador['chave_pix'];
$descricao = $organizador['descricao_organizador'];

// Lógica para exclusão de conta
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['excluir'])) {
    $senha_digitada = $_POST['senha_exclusao'];

    if (password_verify($senha_digitada, $organizador['senha_organizador'])) {
        $result = $dados->excluirOrganizador($id_loginOrg['id_loginOrg']);

        if ($result) {
            session_destroy();
            header("Location: ../login/login.php");
            exit();
        } else {
            echo "Erro ao excluir o organizador. Tente novamente.";
        }
    } else {
        echo "Senha incorreta!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Área do Organizador</title>
  <link rel="stylesheet" href="perfil-organizador.css">
  <link rel="stylesheet" href="../detalhesOrg/cabeçalho.css">
  <link rel="stylesheet" href="../detalhesOrg/rodape.css">
</head>

<body>
  <header id="headerOrg"></header>

  <main class="organizador">
    <div class="profile-container">
      <div class="profile-info">
        <!-- Exibindo a imagem do perfil do organizador -->
        <?php
        // Verificando se a imagem de perfil existe
        if (!empty($imagem_perfil)) {
            // Caminho completo da imagem
            $imagemPath = "../imagens/perfis/" . htmlspecialchars($imagem_perfil);
            if (file_exists($imagemPath)) {
                echo "<img class='profile-picture' src='$imagemPath' alt='Imagem do Organizador'>";
            } else {
                // Caso a imagem não exista, exibe uma imagem padrão
                echo "<img class='profile-picture' src='../imagens/perfis/default-image.jpg' alt='Imagem do Organizador'>";
            }
        } else {
            // Caso não haja imagem, exibe uma imagem padrão
            echo "<img class='profile-picture' src='../imagens/perfis/default-image.jpg' alt='Imagem do Organizador'>";
        }
        ?>
        
        <div class="profile-text">
          <!-- Exibindo os dados do organizador -->
          <h1><?php echo htmlspecialchars($nome_organizador); ?></h1>
          <h4>Email para contato: <?php echo htmlspecialchars($email_contato); ?></h4>
          <h4>Descrição do seu perfil: <?php echo htmlspecialchars($descricao); ?></h4>
        </div>
       
      </div> 
    </div>
  </main>



  <main class="organizador">
    <section class="actions-section">
      <h1>Ações Rápidas</h1>
      <div class="actions-grid">
        <div class="action-card">
          <h3>Criar Evento</h3>
          <p>Configure um novo evento e comece a vender ingressos.</p>
          <a href="../organizador/criar-evento.php">
            <button class="botaoacao">Começar</button>
          </a>
        </div>

        <div class="action-card">
          <h3>Configurações</h3>
          <p>Personalize sua conta e preferências.</p>
          <a href="../organizador/editar-perfil.php">
            <button class="botaoacao">Alterar</button>
          </a>
        </div>
      </div>
    </section>
  </main>

  <footer id="footerOrg"></footer>

  <script>
        fetch('../detalhesOrg/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('headerOrg').innerHTML = data;
            });

        fetch('../detalhesOrg/rodape.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footerOrg').innerHTML = data;
            });

        let menuVisible = false;

        function toggleMenu() {
            const menu = document.querySelector('.dropdown-menu');
            menuVisible = !menuVisible;
            menu.style.display = menuVisible ? 'block' : 'none';
        }

        document.addEventListener('click', function(event) {
            const menu = document.querySelector('.dropdown-menu');
            const menuButton = document.querySelector('.menu-icon');

            if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
                menuVisible = false;
                menu.style.display = 'none';
            }
        });
    </script>

</body>

</html>
