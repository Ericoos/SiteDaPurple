document.addEventListener("DOMContentLoaded", () => {
  const carouselContainer = document.querySelector(".ingresso-carrosel");
  const cards = document.querySelectorAll(".ingresso-card");
  const maxCardsPerPage = 3;
  const pageIndicator = document.querySelector("#paginaAtual");
  let currentPage = 0;

  const prevButton = document.querySelector("#prevButton");
  const nextButton = document.querySelector("#nextButton");

  function updateCarousel() {
      const start = currentPage * maxCardsPerPage;
      const end = start + maxCardsPerPage;

      cards.forEach((card) => {
          card.style.display = "none";
      });

      const visibleCards = [];
      cards.forEach((card, index) => {
          if (index >= start && index < end) {
              card.style.display = "flex";
              visibleCards.push(card);
          }
      });

      if (visibleCards.length === 1) {
          carouselContainer.classList.remove("center", "space-between");
          carouselContainer.style.justifyContent = "flex-start";
      } else if (visibleCards.length === 2) {
          carouselContainer.classList.remove("space-between");
          carouselContainer.style.justifyContent = "center";
      } else if (visibleCards.length === 3) {
          carouselContainer.style.justifyContent = "space-between";
      }

      prevButton.disabled = currentPage === 0;
      nextButton.disabled = end >= cards.length;

      pageIndicator.textContent = `Página ${currentPage + 1}`;
  }

  prevButton.addEventListener("click", () => {
      if (currentPage > 0) {
          currentPage--;
          updateCarousel();
      }
  });

  nextButton.addEventListener("click", () => {
      if ((currentPage + 1) * maxCardsPerPage < cards.length) {
          currentPage++;
          updateCarousel();
      }
  });

  updateCarousel();
});
