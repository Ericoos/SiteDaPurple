<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tela Inicial</title>
  <link rel="stylesheet" href="carrossel.css">
  <link rel="stylesheet" href="evento_destaque.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css">
  <link rel="stylesheet" href="para_produtores.css">
  <link rel="stylesheet" href="para_produtores.css">
  <link rel="stylesheet" href="../detalhes/cabeçalho.css">
  <link rel="stylesheet" href="../detalhes/rodape.css">
</head>

<body>

<header id="header"></header>

  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>

  <div class="single-item">
    <a href="#" class="link-container">
      <div class="container">
        <div class="content">
          <div class="image">
            <img src="https://via.placeholder.com/600x400" alt="Imagem Exemplo">
          </div>
          <div class="info">
            <h2>Título do Evento</h2>
            <p><strong>Data:</strong> 12 Dez • 2024</p>
            <p><strong>Local:</strong> Rio de Janeiro, RJ</p>
            <p><strong>Descrição:</strong> Uma festa incrível com muita música e diversão para todos!</p>
          </div>
        </div>
      </div>
    </a>

    <a href="#" class="link-container">
      <div class="container">
        <div class="content">
          <div class="image">
            <img src="https://via.placeholder.com/600x400" alt="Imagem Exemplo">
          </div>
          <div class="info">
            <h2>Outro Evento</h2>
            <p><strong>Data:</strong> 15 Dez • 2024</p>
            <p><strong>Local:</strong> São Paulo, SP</p>
            <p><strong>Descrição:</strong> Uma festa fantástica com convidados especiais!</p>
          </div>
        </div>
      </div>
    </a>

  </div>

  <script type="text/javascript">
    $(document).ready(function() {
      $('.single-item').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 7000,
      });
    });
  </script>

  <main class="cliente">
    <div class="background-cards">
      <div class="carrossel-nav">
        <button class="nav prev"><i class="fas fa-chevron-left"></i></button>
        <h1>Festas</h1>
        <button class="nav next"><i class="fas fa-chevron-right"></i></button>
      </div>
      <div class="carrossel-container">
        <div class="carrossel-wrapper">
          <div class="carrossel-inner center">
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 1">
                <div class="card-content">
                  <h3>Festa na Praia</h3>
                  <p>Rio de Janeiro, RJ</p>
                  <p>12 Dez • 2024 - 18:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 2">
                <div class="card-content">
                  <h3>Noite Eletrônica</h3>
                  <p>São Paulo, SP</p>
                  <p>25 Dez • 2024 - 22:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 3">
                <div class="card-content">
                  <h3>Show de Rock</h3>
                  <p>Belo Horizonte, MG</p>
                  <p>05 Jan • 2025 - 20:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 4">
                <div class="card-content">
                  <h3>Festival Cultural</h3>
                  <p>Curitiba, PR</p>
                  <p>18 Fev • 2025 - 15:00</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="background-cards">
      <div class="carrossel-nav">
        <button class="nav prev"><i class="fas fa-chevron-left"></i></button>
        <h1>Eventos</h1>
        <button class="nav next"><i class="fas fa-chevron-right"></i></button>
      </div>
      <div class="carrossel-container">
        <div class="carrossel-wrapper">
          <div class="carrossel-inner center">

            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 1">
                <div class="card-content">
                  <h3>Festa na Praia</h3>
                  <p>Rio de Janeiro, RJ</p>
                  <p>12 Dez • 2024 - 18:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 2">
                <div class="card-content">
                  <h3>Noite Eletrônica</h3>
                  <p>São Paulo, SP</p>
                  <p>25 Dez • 2024 - 22:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 3">
                <div class="card-content">
                  <h3>Show de Rock</h3>
                  <p>Belo Horizonte, MG</p>
                  <p>05 Jan • 2025 - 20:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 4">
                <div class="card-content">
                  <h3>Festival Cultural</h3>
                  <p>Curitiba, PR</p>
                  <p>18 Fev • 2025 - 15:00</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="background-cards">
      <div class="carrossel-nav">
        <button class="nav prev"><i class="fas fa-chevron-left"></i></button>
        <h1>Shows</h1>
        <button class="nav next"><i class="fas fa-chevron-right"></i></button>
      </div>
      <div class="carrossel-container">
        <div class="carrossel-wrapper">
          <div class="carrossel-inner center">
            <!-- Exemplos de cards -->
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 1">
                <div class="card-content">
                  <h3>Festa na Praia</h3>
                  <p>Rio de Janeiro, RJ</p>
                  <p>12 Dez • 2024 - 18:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 2">
                <div class="card-content">
                  <h3>Noite Eletrônica</h3>
                  <p>São Paulo, SP</p>
                  <p>25 Dez • 2024 - 22:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 3">
                <div class="card-content">
                  <h3>Show de Rock</h3>
                  <p>Belo Horizonte, MG</p>
                  <p>05 Jan • 2025 - 20:00</p>
                </div>
              </div>
            </div>
            <div class="carrossel-item">
              <div class="card">
                <img src="https://via.placeholder.com/300x150" alt="Evento 4">
                <div class="card-content">
                  <h3>Festival Cultural</h3>
                  <p>Curitiba, PR</p>
                  <p>18 Fev • 2025 - 15:00</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <div class="heroi">
    <div class="texto-heroi">
      <h1>Crie, publique e venda<br>eventos com facilidade</h1>
      <p>Junte-se a milhares de organizadores de eventos e facilite o gerenciamento com a Purple.</p>
      <a href="/lading_page/lading.html" class="botaoacao">Crie seu evento</a>
    </div>
    <div class="imagem-heroi">
      <img src="../imagens/neguinho_1_1.png" alt="Imagem ilustrativa">
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

  <footer id="footer"></footer>
  <script>
    $(document).ready(function() {
      var $carrossel = $('.center');

      $carrossel.slick({
        centerMode: true,
        centerPadding: '60px',
        slidesToShow: 3,
        arrows: false,
        responsive: [{
            breakpoint: 768,
            settings: {
              arrows: false,
              centerMode: true,
              centerPadding: '40px',
              slidesToShow: 3
            }
          },
          {
            breakpoint: 480,
            settings: {
              arrows: false,
              centerMode: true,
              centerPadding: '40px',
              slidesToShow: 1
            }
          }
        ]
      });

      // Função para navegar para o slide anterior
      $('.nav.prev').on('click', function() {
        $carrossel.slick('slickPrev');
      });

      // Função para navegar para o próximo slide
      $('.nav.next').on('click', function() {
        $carrossel.slick('slickNext');
      });
    });
  </script>

  <script>
    fetch('../detalhes/cabeçalho.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('header').innerHTML = data;
        });

    fetch('../detalhes/rodape.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('footer').innerHTML = data;
        });

    document.addEventListener('click', function(event) {
      const menu = document.querySelector('.dropdown-menu');
      const menuButton = document.querySelector('.menu-icon');

      if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
        menuVisible = false;
        menu.style.display = 'none';
      }
    });
  </script>

</body>

</html>