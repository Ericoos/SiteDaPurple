document.addEventListener('DOMContentLoaded', () => {
  const carrosselInner = document.querySelector('.carrossel-inner');
  const prevButton = document.querySelector('.nav.prev');
  const nextButton = document.querySelector('.nav.next');
  const items = document.querySelectorAll('.carrossel-item');

  let currentIndex = 0;
  const itemsPerView = getItemsPerView();

  function getItemsPerView() {
      if (window.innerWidth <= 480) return 1;
      if (window.innerWidth <= 768) return 2;
      return 3;
  }

  function updateCarrossel() {
      const offset = -(currentIndex * (100 / itemsPerView));
      carrosselInner.style.transform = `translateX(${offset}%)`;
  }

  function handleResize() {
      const newItemsPerView = getItemsPerView();
      if (newItemsPerView !== itemsPerView) {
          currentIndex = 0;
          updateCarrossel();
      }
  }

  prevButton.addEventListener('click', () => {
      currentIndex = Math.max(currentIndex - 1, 0);
      updateCarrossel();
  });

  nextButton.addEventListener('click', () => {
      const maxIndex = Math.ceil(items.length / itemsPerView) - 1;
      currentIndex = Math.min(currentIndex + 1, maxIndex);
      updateCarrossel();
  });

  window.addEventListener('resize', handleResize);

  updateCarrossel();
});
