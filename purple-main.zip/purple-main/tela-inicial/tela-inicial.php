<?php
session_start();
include('../bd/verificaLogin.php');
include_once('../bd/conexao.php');

$conexao = new banco();
$conn = $conexao->conectar();

// Query para buscar todos os eventos ativos
$query = "SELECT id_evento, nome_evento, descricao_evento, data_evento, hora_evento, estado_evento, localidade_evento, banner, tipo_evento
          FROM evento
          WHERE data_evento >= CURDATE()";
$stmt = $conn->prepare($query);
$stmt->execute();

$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tela Inicial</title>
  <link rel="stylesheet" href="carrossel.css">
  <link rel="stylesheet" href="evento_destaque.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css">
  <link rel="stylesheet" href="para_produtores.css">
  <link rel="stylesheet" href="../detalhes/cabeçalho.css">
  <link rel="stylesheet" href="../detalhes/rodape.css">
</head>

<body>

<header id="header"></header>

<div class="single-item">
  <?php foreach ($eventos as $evento): ?>
    <a href="../tela-de-compra/tela-de-compra.php?id_evento=<?= htmlspecialchars($evento['id_evento']) ?>" class="link-container">
      <div class="container">
        <div class="content">
          <div class="image">
            <img src="../imagens/banners/<?= htmlspecialchars($evento['banner']) ?>" alt="<?= htmlspecialchars($evento['nome_evento']) ?>">
          </div>
          <div class="info">
            <h2><?= htmlspecialchars($evento['nome_evento']) ?></h2>
            <p><strong>Data:</strong> <?= date("d M • Y", strtotime($evento['data_evento'])) ?></p>
            <p><strong>Local:</strong> <?= htmlspecialchars($evento['localidade_evento']) ?>, <?= htmlspecialchars($evento['estado_evento']) ?></p>
            <p><strong>Descrição:</strong> <?= htmlspecialchars($evento['descricao_evento']) ?></p>
          </div>
        </div>
      </div>
    </a>
  <?php endforeach; ?>
</div>


<script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
    
    $('.single-item').slick({
      dots: true, 
      infinite: true, 
      speed: 300, 
      slidesToShow: 1, 
      slidesToScroll: 1, 
      autoplay: true, 
      autoplaySpeed: 7000, 
    });
  });
</script>


<main class="cliente">

  <div class="background-cards">
    <div class="carrossel-nav">
      <button class="nav prev">&lt;</button>
      <h1>Festas</h1>
      <button class="nav next">&gt;</button>
    </div>
    <div class="carrossel-container">
      <div class="carrossel-wrapper">
        <div class="carrossel-inner center">
          <?php foreach ($eventos as $evento): ?>
            <?php if ($evento['tipo_evento'] === 'festa'): ?>
              <div class="carrossel-item">
                <div class="card">
                  <a href="../tela-de-compra/tela-de-compra.php?id_evento=<?= htmlspecialchars($evento['id_evento']) ?>">
                    <img src="../imagens/banners/<?= htmlspecialchars($evento['banner']) ?>" alt="<?= htmlspecialchars($evento['nome_evento']) ?>">
                    <div class="card-content">
                      <h3><?= htmlspecialchars($evento['nome_evento']) ?></h3>
                      <p><?= htmlspecialchars($evento['localidade_evento']) ?> - <?= htmlspecialchars($evento['estado_evento']) ?></p>
                      <p><?= date("d M • Y", strtotime($evento['data_evento'])) ?> - <?= date("H:i", strtotime($evento['hora_evento'])); ?></p>
                    </div>
                  </a>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Abas: Eventos -->
  <div class="background-cards">
    <div class="carrossel-nav">
      <button class="nav prev">&lt;</button>
      <h1>Eventos</h1>
      <button class="nav next">&gt;</button>
    </div>
    <div class="carrossel-container">
      <div class="carrossel-wrapper">
        <div class="carrossel-inner center">
          <?php foreach ($eventos as $evento): ?>
            <?php if ($evento['tipo_evento'] === 'evento'): ?>
              <div class="carrossel-item">
                <div class="card">
                  <a href="../tela-de-compra/tela-de-compra.php?id_evento=<?= htmlspecialchars($evento['id_evento']) ?>">
                    <img src="../imagens/banners/<?= htmlspecialchars($evento['banner']) ?>" alt="<?= htmlspecialchars($evento['nome_evento']) ?>">
                    <div class="card-content">
                      <h3><?= htmlspecialchars($evento['nome_evento']) ?></h3>
                      <p><?= htmlspecialchars($evento['localidade_evento']) ?> - <?= htmlspecialchars($evento['estado_evento']) ?></p>
                      <p><?= date("d M • Y", strtotime($evento['data_evento'])) ?> - <?= date("H:i", strtotime($evento['hora_evento'])); ?></p>
                    </div>
                  </a>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Abas: Shows -->
  <div class="background-cards">
    <div class="carrossel-nav">
      <button class="nav prev">&lt;</button>
      <h1>Shows</h1>
      <button class="nav next">&gt;</button>
    </div>
    <div class="carrossel-container">
      <div class="carrossel-wrapper">
        <div class="carrossel-inner center">
          <?php foreach ($eventos as $evento): ?>
            <?php if ($evento['tipo_evento'] === 'show'): ?>
              <div class="carrossel-item">
                <div class="card">
                  <a href="../tela-de-compra/tela-de-compra.php?id_evento=<?= htmlspecialchars($evento['id_evento']) ?>">
                    <img src="../imagens/banners/<?= htmlspecialchars($evento['banner']) ?>" alt="<?= htmlspecialchars($evento['nome_evento']) ?>">
                    <div class="card-content">
                      <h3><?= htmlspecialchars($evento['nome_evento']) ?></h3>
                      <p><?= htmlspecialchars($evento['localidade_evento']) ?> - <?= htmlspecialchars($evento['estado_evento']) ?></p>
                      <p><?= date("d M • Y", strtotime($evento['data_evento'])) ?> - <?= date("H:i", strtotime($evento['hora_evento'])); ?></p>
                    </div>
                  </a>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</main>

<div class="heroi">
    <div class="texto-heroi">
      <h1>Crie, publique e venda<br>eventos com facilidade</h1>
      <p>Junte-se a milhares de organizadores de eventos e facilite o gerenciamento com a Purple.</p>
      <a href="/lading_page/lading.html" class="botaoacao">Crie seu evento</a>
    </div>
    <div class="imagem-heroi">
      <img src="../imagens/neguinho_1_1.png" alt="Imagem ilustrativa">
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<footer id="footer"></footer>
<script>
  fetch('../detalhes/cabeçalho.html')
    .then(response => response.text())
    .then(data => {
      document.getElementById('header').innerHTML = data;
    });

  fetch('../detalhes/rodape.html')
    .then(response => response.text())
    .then(data => {
      document.getElementById('footer').innerHTML = data;
    });
</script>

<script>
    let menuVisible = false;

    function toggleMenu() {
        const menu = document.querySelector('.dropdown-menu');
        menuVisible = !menuVisible;
        menu.style.display = menuVisible ? 'block' : 'none';
    }

    document.addEventListener('click', function(event) {
        const menu = document.querySelector('.dropdown-menu');
        const menuButton = document.querySelector('.menu-icon');

        if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
            menuVisible = false;
            menu.style.display = 'none';
        }
    });
</script>

</body>
</html>
