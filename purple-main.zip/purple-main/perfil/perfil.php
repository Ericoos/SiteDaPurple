<?php
session_start();

if (isset($_SESSION['clientes'])) {
    $idUsuario = $_SESSION['clientes'];
} else {
    echo "Usuário não encontrado!";
    exit;
}

include('../bd/verificaLogin.php');
include('../bd/user.php');

$dados = new Usuario();
$usuario = $dados->pegarDadosCliente($idUsuario);

if (!$usuario) {
    echo "Usuário não encontrado!";
    exit;
}

$id_cadastro = $usuario["id_cadastro"];
$nome = $usuario["nome"];
$email = $usuario["email"];
$telefone = $usuario['telefone'];
$idade = $usuario['idade'];
$senha = $usuario['senha'];
$sessao = $_SESSION['clientes'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nomeNovo = $_POST['nome'];
    $emailNovo = $_POST['email'];
    $telefoneNovo = $_POST['telefone'];
    $idadeNova = $_POST['idade'];
    $senhaNova = isset($_POST['senha']) ? $_POST['senha'] : null;

    $result = $dados->atualizarPerfilUsuario($idUsuario, $nomeNovo, $emailNovo, $telefoneNovo, $idadeNova, $senhaNova);

    if ($result) {
        header("Location: perfil.php");
        exit();
    } else {
        echo "Erro ao atualizar o perfil.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../perfil/perfil.css">
    <link rel="stylesheet" href="../detalhes/cabeçalho.css">
    <link rel="stylesheet" href="../detalhes/rodape.css">
    <title>Perfil</title>
</head>

<body>
    <header id="header"></header>

    <main class="cliente">

        <form action="perfil.php" method="POST">
            <fieldset>
            <h1 style="padding-top: 15px;">Editar Perfil</h1>
                <div class="perfil-card">
                    <div class="fundo-info">
                        <label for="nome">Nome Completo:</label>
                        <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>">
                    </div>
                    <div class="fundo-info">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
                    </div>
                    <div class="fundo-info">
                        <label for="telefone">Telefone:</label>
                        <input type="text" id="telefone" name="telefone" value="<?php echo htmlspecialchars($telefone); ?>" required maxlength="15" oninput="formatarTelefone(this)">
                    </div>
                    <div class="fundo-info">
                        <label for="idade">Idade:</label>
                        <input type="text" id="idade" name="idade" value="<?php echo htmlspecialchars($idade); ?>">
                    </div>
                    <div class="fundo-info">
                        <label for="senha">Nova Senha:</label>
                        <input type="password" id="senha" name="senha" placeholder="Digite a nova senha">
                    </div>
                    <div>
                    <button class="botaoacao" type="submit">Atualizar Perfil</button>
                    <button class="buttonexcluir" type="submit">Excluir</button>
                    </div>
                </div>
            </fieldset>
        </form>

    </main>

    <script>
        fetch('../detalhes/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header').innerHTML = data;
            });

    </script>

<footer id="footer"></footer>



<script>
    fetch('../detalhes/cabeçalho.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('header').innerHTML = data;
        });

    fetch('../detalhes/rodape.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('footer').innerHTML = data;
        });
</script>

<script>
    let menuVisible = false;

    function toggleMenu() {
        const menu = document.querySelector('.dropdown-menu');
        menuVisible = !menuVisible;
        menu.style.display = menuVisible ? 'block' : 'none';
    }

    document.addEventListener('click', function(event) {
        const menu = document.querySelector('.dropdown-menu');
        const menuButton = document.querySelector('.menu-icon');

        if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
            menuVisible = false;
            menu.style.display = 'none';
        }
    });
</script>
</body>

</html>