document.addEventListener("DOMContentLoaded", () => {
  const popup = document.getElementById("popupConfirmacao");
  const cancelarBtn = document.getElementById("cancelarExclusao");

  document.querySelectorAll(".ver-ingresso[type='submit']").forEach((botao) => {
    botao.addEventListener("click", (e) => {
      e.preventDefault();
      popup.style.display = "flex";
    });
  });

  cancelarBtn.addEventListener("click", () => {
    popup.style.display = "none";
  });

  popup.addEventListener("click", (e) => {
    if (e.target === popup) {
      popup.style.display = "none";
    }
  });
});
