<?php
include('../bd/verificaLogin.php');
include_once('../bd/conexao.php');
include_once('../tela-de-compra/backendteladecompra.php');

// Buscar evento específico pelo ID
if (isset($evento) && $evento) {
    $_SESSION['id_evento'] = $evento['id_evento'];
} else {
    echo "Erro: Evento não encontrado!";
    exit;
}

$statusCompra = "SELECT status_compra FROM pagamento WHERE id_evento = :id_evento AND id_cadastro = :id_cadastro";
$stmtStatusCompra = $conn->prepare($statusCompra);
$stmtStatusCompra->bindParam(':id_evento', $_SESSION['id_evento'], PDO::PARAM_INT);
$stmtStatusCompra->bindParam(':id_cadastro', $_SESSION['clientes'], PDO::PARAM_INT);
$stmtStatusCompra->execute();

$status = $stmtStatusCompra->fetch(PDO::FETCH_ASSOC);

if ($status && $status['status_compra'] === 'Finalizado') {
    $queryAtualizarStatus = "
        UPDATE pagamento
        SET status_compra = 'Expirado'
        WHERE id_evento = :id_evento AND id_cadastro = :id_cadastro";
    $stmtAtualizarStatus = $conn->prepare($queryAtualizarStatus);
    $stmtAtualizarStatus->bindParam(':id_evento', $_SESSION['id_evento'], PDO::PARAM_INT);
    $stmtAtualizarStatus->bindParam(':id_cadastro', $_SESSION['clientes'], PDO::PARAM_INT);
    $stmtAtualizarStatus->execute();

    $queryFinalizarCarrinho = "
        UPDATE carrinho
        SET status_carrinho = 'Finalizado'
        WHERE id_evento = :id_evento AND id_cadastro = :id_cadastro";
    $stmtFinalizarCarrinho = $conn->prepare($queryFinalizarCarrinho);
    $stmtFinalizarCarrinho->bindParam(':id_evento', $_SESSION['id_evento'], PDO::PARAM_INT);
    $stmtFinalizarCarrinho->bindParam(':id_cadastro', $_SESSION['clientes'], PDO::PARAM_INT);
    $stmtFinalizarCarrinho->execute();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Compra</title>
    <link rel="stylesheet" href="produtos-adicionais.css">
    <link rel="stylesheet" href="tela-de-compraofc.css">
    <link rel="stylesheet" href="../detalhes/cabeçalho.css">
    <link rel="stylesheet" href="../detalhes/rodape.css">
</head>

<body>

<header id="header"></header>

<main class="evento-container">
    <div class="banner">
        <div class="imagem" style="background-image: url('../imagens/banners/<?= htmlspecialchars($evento['banner']); ?>');"></div>
    </div>

    <section class="conteudo-principal">
        <!-- Descrição do Evento -->
        <section class="descricao-evento">
            <h1><?= htmlspecialchars($evento['nome_evento']); ?></h1>

            <?php
            // Converter datas
            $mesesEmPortugues = [
                'January' => 'Janeiro',
                'February' => 'Fevereiro',
                'March' => 'Março',
                'April' => 'Abril',
                'May' => 'Maio',
                'June' => 'Junho',
                'July' => 'Julho',
                'August' => 'Agosto',
                'September' => 'Setembro',
                'October' => 'Outubro',
                'November' => 'Novembro',
                'December' => 'Dezembro'
            ];

            $date = new DateTime($evento['data_evento']);
            $diaSemana = $date->format('l');
            $diasSemanaEmPortugues = [
                'Sunday' => 'Domingo',
                'Monday' => 'Segunda-feira',
                'Tuesday' => 'Terça-feira',
                'Wednesday' => 'Quarta-feira',
                'Thursday' => 'Quinta-feira',
                'Friday' => 'Sexta-feira',
                'Saturday' => 'Sábado'
            ];

            $diaSemanaPortugues = $diasSemanaEmPortugues[$diaSemana];

            $mes = $date->format('F');
            $mesPortugues = $mesesEmPortugues[$mes];

            $horaEvento = date("H:i", strtotime($evento['hora_evento']));
            ?>

            <p>
                <?= $diaSemanaPortugues; ?> às <?= $horaEvento; ?>
            </p>
            <p>
                <?= $date->format('d'); ?> de <?= $mesPortugues; ?>
            </p>

            <h1>DESCRIÇÃO DO EVENTO</h1>
            <p><?= nl2br(htmlspecialchars($evento['descricao_evento'])); ?></p>

            <a href="https://www.google.com/maps/search/<?= urlencode($evento['cep_evento']); ?>" target="_blank" class="ver-mapa">
                Ver no mapa
            </a>

        </section>

        
        <section class="opcoes-compra-carrinho">
            
            <form action="backendteladecompra.php?id_evento=<?= $evento['id_evento']; ?>" method="POST">

                <!-- Ingressos -->
                <section class="comprar-ingresso">
                    <div class="produtos">
                        <h1>Ingressos</h1>
                        <ul>
                            <?php
                            // Buscar ingressos do banco de dados
                            $queryIngressos = "SELECT * FROM produto WHERE tipo = 'ingresso' AND id_evento = :id_evento";
                            $stmtIngressos = $conn->prepare($queryIngressos);
                            $stmtIngressos->bindParam(':id_evento', $_SESSION['id_evento'], PDO::PARAM_INT);
                            $stmtIngressos->execute();
                            $ingressos = $stmtIngressos->fetchAll(PDO::FETCH_ASSOC);
                            
                            foreach ($ingressos as $index => $ingresso) :
                            ?>
                                <li>
                                    <label>
                                        <strong><?= htmlspecialchars($ingresso['nome']); ?></strong>
                                        <br>
                                        <span><strong>Preço:</strong> R$ <?= number_format($ingresso['valor'], 2, ',', '.'); ?></span>
                                    </label>
                                    <div class="quantidade-controle">
                                        <button type="button" onclick="alterarQuantidade('quantidade-<?= $index; ?>', -1)" <?= $ingresso['quantidade'] <= 0 ? 'disabled' : ''; ?>>-</button>
                                        <input
                                            type="number"
                                            id="quantidade-<?= $index; ?>"
                                            name="produtos[<?= $ingresso['id_produto']; ?>][quantidade]"
                                            value="0"
                                            min="0"
                                            <?= $ingresso['quantidade'] <= 0 ? 'disabled' : ''; ?>>
                                        <button type="button" onclick="alterarQuantidade('quantidade-<?= $index; ?>', 1)" <?= $ingresso['quantidade'] <= 0 ? 'disabled' : ''; ?>>+</button>
                                    </div>
                                    <div class="detalhes" id="ingresso-detalhes-<?= $index; ?>">
                                        <p><strong>Descrição:</strong> <?= htmlspecialchars($ingresso['descricao']); ?></p>
                                        <p><strong>Quantidade disponível:</strong> <?= htmlspecialchars($ingresso['quantidade_pfesta']); ?></p>
                                    </div>
                                    <button class="botaoacao" type="button" onclick="toggleDetalhes('ingresso-detalhes-<?= $index; ?>')">Ver mais</button>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </section>

                <!-- Benefícios -->
                <section class="comprar-beneficio">
                    <div class="produtos">
                        <h1>Benefícios</h1>
                        <ul>
                            <?php
                            // Buscar benefícios do banco de dados
                            $queryBeneficios = "SELECT * FROM produto WHERE tipo = 'beneficio' AND id_evento = :id_evento";
                            $stmtBeneficios = $conn->prepare($queryBeneficios);
                            $stmtBeneficios->bindParam(':id_evento', $_SESSION['id_evento'], PDO::PARAM_INT);
                            $stmtBeneficios->execute();
                            $beneficios = $stmtBeneficios->fetchAll(PDO::FETCH_ASSOC);
                            
                            foreach ($beneficios as $index => $beneficio) :
                            ?>
                                <li>
                                    <label>
                                        <strong><?= htmlspecialchars($beneficio['nome']); ?></strong>
                                        <br>
                                        <span><strong>Preço:</strong> R$ <?= number_format($beneficio['valor'], 2, ',', '.'); ?></span>
                                    </label>
                                    <div class="quantidade-controle">
                                        <button type="button" onclick="alterarQuantidade('quantidade-beneficio-<?= $index; ?>', -1)" <?= $beneficio['quantidade'] <= 0 ? 'disabled' : ''; ?>>-</button>
                                        <input type="number" id="quantidade-beneficio-<?= $index; ?>" name="produtos[<?= $beneficio['id_produto']; ?>][quantidade]" value="0" min="0" <?= $beneficio['quantidade'] <= 0 ? 'disabled' : ''; ?>>
                                        <button type="button" onclick="alterarQuantidade('quantidade-beneficio-<?= $index; ?>', 1)" <?= $beneficio['quantidade'] <= 0 ? 'disabled' : ''; ?>>+</button>
                                    </div>
                                    <div class="detalhes" id="beneficio-detalhes-<?= $index; ?>">
                                        <p><strong>Descrição:</strong> <?= htmlspecialchars($beneficio['descricao']); ?></p>
                                        <p><strong>Quantidade disponível:</strong> <?= htmlspecialchars($beneficio['quantidade_pfesta']); ?></p>
                                    </div>
                                    <button class="botaoacao" type="button" onclick="toggleDetalhes('beneficio-detalhes-<?= $index; ?>')">Ver mais</button>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </section>

                <!-- Botão único para adicionar ao carrinho -->
                <button type="submit" class="selecionar-ingresso">Adicionar ao carrinho</button>
            </form>
        </section>
    </main>

    <footer id="footer"></footer>

    <script>
        // Função para alterar quantidade
        function alterarQuantidade(id, incremento) {
            const input = document.getElementById(id);
            let quantidade = parseInt(input.value) + incremento;
            if (quantidade < 1) quantidade = 1; // Não permite valores menores que 1
            input.value = quantidade;
        }

        // Função para exibir ou ocultar detalhes
        function toggleDetalhes(id) {
            const detalhes = document.getElementById(id);
            if (detalhes.style.display === 'none' || detalhes.style.display === '') {
                detalhes.style.display = 'block';
            } else {
                detalhes.style.display = 'none';
            }
        }
    </script>

<footer id="footer"></footer>
<script>
  fetch('../detalhes/cabeçalho.html')
    .then(response => response.text())
    .then(data => {
      document.getElementById('header').innerHTML = data;
    });

  fetch('../detalhes/rodape.html')
    .then(response => response.text())
    .then(data => {
      document.getElementById('footer').innerHTML = data;
    });
</script>

<script>
    let menuVisible = false;

    function toggleMenu() {
        const menu = document.querySelector('.dropdown-menu');
        menuVisible = !menuVisible;
        menu.style.display = menuVisible ? 'block' : 'none';
    }

    document.addEventListener('click', function(event) {
        const menu = document.querySelector('.dropdown-menu');
        const menuButton = document.querySelector('.menu-icon');

        if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
            menuVisible = false;
            menu.style.display = 'none';
        }
    });
</script>

</body>

</html>
