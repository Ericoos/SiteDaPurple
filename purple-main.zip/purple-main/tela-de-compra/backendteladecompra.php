<?php

include('../bd/verificaLogin.php');
include_once('../bd/conexao.php');
include_once('../bd/carrinho.php');
include_once('../bd/festa.php');

if (isset($_GET['id_evento'])) {
    $id_evento = $_GET['id_evento'];
} else {
    echo "ID do evento não fornecido!";
    exit;
}

$festa = new Festa();
$evento = $festa->buscarEventoPorId($id_evento);

if (!$evento) {
    die("Erro: Evento não encontrado!");
}

$connbanco = new banco();
$conn = $connbanco->conectar();

// Verifica se o cliente está logado
if (!isset($_SESSION['clientes'])) {
    header("Location: ../login.php");
    exit;
}

$id_cadastro = $_SESSION['clientes'];

$carrinho = new Carrinho();

$carrinhoExistente = $carrinho->verificarCarrinhoExistente($id_evento, $id_cadastro);

if ($carrinhoExistente) {
    // Carrinho já existe, obter o ID do carrinho
    $id_carrinho = $carrinhoExistente['id_carrinho'];
} else {
    // Não existe carrinho, criar um novo
    $id_carrinho = $carrinho->criarCarrinho($id_evento, $id_cadastro);
}

// Consultar os produtos relacionados ao evento
$queryProdutos = "SELECT id_produto, nome, tipo, descricao, valor, quantidade, quantidade_pfesta 
                  FROM produto 
                  WHERE id_evento = :id_evento";

$stmtProdutos = $conn->prepare($queryProdutos);
$stmtProdutos->bindParam(':id_evento', $id_evento, PDO::PARAM_INT);
$stmtProdutos->execute();

$produtos = $stmtProdutos->fetchAll(PDO::FETCH_ASSOC);

// Categorizar produtos por tipo
$ingressos = [];
$beneficios = [];

foreach ($produtos as $produto) {
    if ($produto['tipo'] === 'ingresso') {
        $ingressos[] = $produto;
    } elseif ($produto['tipo'] === 'beneficio') {
        $beneficios[] = $produto;
    }
}


// Código permanece idêntico até a verificação de produtos

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['produtos'])) {
    $produtosSelecionados = $_POST['produtos'];

    foreach ($produtosSelecionados as $idProduto => $produto) {
        $quantidade = isset($produto['quantidade']) ? (int)$produto['quantidade'] : 0;

        if ($quantidade > 0) {
            $queryValorProduto = "SELECT valor, quantidade_pfesta FROM produto WHERE id_produto = :id_produto";
            $stmtValorProduto = $conn->prepare($queryValorProduto);
            $stmtValorProduto->bindParam(':id_produto', $idProduto, PDO::PARAM_INT);
            $stmtValorProduto->execute();
            $resultadoProduto = $stmtValorProduto->fetch(PDO::FETCH_ASSOC);

            if ($resultadoProduto) {
                $valorProduto = (float)$resultadoProduto['valor'];
                $quantidadeDisponivel = (int)$resultadoProduto['quantidade_pfesta'];

                if ($quantidade > $quantidadeDisponivel) {
                    echo "Erro: Quantidade solicitada maior do que a disponível para o produto {$idProduto}.";
                    continue;
                }

                $valor_total = $quantidade * $valorProduto;

                $produtoExistente = $carrinho->verificarProdutoNoCarrinho($id_carrinho, $idProduto);

                if ($produtoExistente) {
                    $carrinho->atualizarProdutoCarrinho($id_carrinho, $idProduto, $quantidade, $valor_total);
                } else {
                    $carrinho->adicionarProdutoCarrinho($id_carrinho, $idProduto, $quantidade, $valor_total);
                }

                $novaQuantidade = $quantidadeDisponivel - $quantidade;
                $queryAtualizarQuantidade = "UPDATE produto SET quantidade_pfesta = :novaQuantidade WHERE id_produto = :id_produto";
                $stmtAtualizarQuantidade = $conn->prepare($queryAtualizarQuantidade);
                $stmtAtualizarQuantidade->bindParam(':novaQuantidade', $novaQuantidade, PDO::PARAM_INT);
                $stmtAtualizarQuantidade->bindParam(':id_produto', $idProduto, PDO::PARAM_INT);
                $stmtAtualizarQuantidade->execute();
            } else {
                echo "Erro: Produto não encontrado no banco de dados.";
            }
        }
    }

    header("Location: ../carrinho/pag-carrinho.php?id_evento=" . $evento['id_evento']);
    exit;
}
?>


