<?php
include('../bd/verificaLogin.php');
include_once('../bd/conexao.php');
include_once('../bd/carrinho.php');
include_once('../bd/festa.php');

if (!isset($_SESSION['clientes'])) {
    header("Location: ../login.php");
    exit;
}

$id_cadastro = $_SESSION['clientes']; // ID do cliente logado
$id_evento = $_GET['id_evento'] ?? null; // ID do evento via GET

if (!$id_evento) {
    echo "Erro: ID do evento não foi fornecido.";
    exit;
}

$connbanco = new banco();
$conn = $connbanco->conectar();
$carrinho = new Carrinho();

// Recupera o ID do carrinho
$id_carrinho = $carrinho->obterIdCarrinho($id_evento, $id_cadastro, $conn);

if (!$id_carrinho) {
    echo "Erro: Carrinho não encontrado para o evento e cliente.";
    exit;
}

// Obter o ID do produto no carrinho
$id_carrinhoProd = $carrinho->obterIdCarrinhoProduto($id_carrinho, $conn);

if (!$id_carrinhoProd) {
    echo "Erro: Produtos não encontrados no carrinho.";
    exit;
}

// Consultar a chave Pix do organizador responsável pelo evento
$queryChavePix = "
    SELECT o.chave_pix
    FROM login_organizador o
    JOIN evento e ON e.id_loginOrg = o.id_loginOrg
    WHERE e.id_evento = :id_evento
";

$stmtChavePix = $conn->prepare($queryChavePix);
$stmtChavePix->bindParam(':id_evento', $id_evento, PDO::PARAM_INT);
$stmtChavePix->execute();

$chavePix = null;
if ($stmtChavePix->rowCount() > 0) {
    $chavePix = $stmtChavePix->fetch(PDO::FETCH_ASSOC)['chave_pix'];
}

$queryCarrinho = "
    SELECT p.id_produto, p.nome, p.valor, p.tipo, cp.quantidade_produtos, cp.valor_total
    FROM carrinho_produtos cp
    JOIN carrinho c ON cp.id_carrinho = c.id_carrinho
    JOIN produto p ON cp.id_produto = p.id_produto
    WHERE c.id_evento = :id_evento AND cp.id_carrinho = :id_carrinho
";

$stmtCarrinho = $conn->prepare($queryCarrinho);
$stmtCarrinho->bindParam(':id_carrinho', $id_carrinho, PDO::PARAM_INT);
$stmtCarrinho->bindParam(':id_evento', $id_evento, PDO::PARAM_INT); // Filtra pelo evento
$stmtCarrinho->execute();

$produtosCarrinho = $stmtCarrinho->fetchAll(PDO::FETCH_ASSOC);

$totalCarrinho = 0;
foreach ($produtosCarrinho as $produto) {
    $totalCarrinho += $produto['valor_total'];  // Calculando o total com base no valor de cada item
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho - Purple</title>
    <link rel="stylesheet" href="../carrinho/carrinho.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="checkout-container">
        <header class="main-header">
            <h1>Carrinho</h1>
            <p>Etapa 1: Recebimento do seu ingresso</p>
        </header>

        <!-- Conteúdo Principal -->
        <div class="content">
            <form class="checkout-form" action="../bd/processar_pagamento.php" method="POST">
                <!-- Campos ocultos -->
                <input type="hidden" name="id_evento" value="<?= htmlspecialchars($id_evento); ?>">
                <input type="hidden" name="id_carrinho" value="<?= htmlspecialchars($id_carrinho); ?>">
                <input type="hidden" name="id_carrinhoProd" value="<?= htmlspecialchars($id_carrinhoProd); ?>">
                <input type="hidden" name="cartao_nome" id="cartao_hidden" value="">
                <input type="hidden" name="pix" id="pix_hidden" value="">

                <div id="etapa1">
                    <h2>Recebimento do ingresso</h2>
                    <div class="form-group">
                        <label for="name">Nome</label>
                        <input type="text" name="nome_pagamento" id="name" placeholder="Digite seu nome" required>
                    </div>
                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <input type="email" name="email_pagamento" id="email" placeholder="Digite seu e-mail" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Telefone</label>
                        <input type="tel" name="telefone_pagamento" id="phone" placeholder="Digite seu telefone" maxlength="15" required>
                    </div>
                    <button type="button" class="btn-submit" id="proximo">Próximo</button>
                </div>

                <div id="etapa2" style="display: none;">
                    <h2>Método de Pagamento</h2>

                    <!-- Botões para escolher entre Pix e Cartão de Crédito -->
                    <div class="payment-methods">
                        <button type="button" id="pagamento-cartao" class="pix-button">Cartão de Crédito</button>
                        <button type="button" id="pagamento-pix" class="pix-button">Pix</button>
                        <hr>
                    </div>

                    <!-- Cartão de Crédito -->
                    <div id="cartao" class="payment-option" style="display: none;">
                        <h3>Informações do Cartão</h3>
                        <div class="card-details">
                            <div class="form-group">
                                <label for="card-name">Nome no Cartão</label>
                                <input type="text" id="card-name" name="cartao_nome" placeholder="Ex: João Silva">
                            </div>
                            <div class="form-group">
                                <label for="card-number">Número do Cartão</label>
                                <input type="text" id="card-number" name="cartao_numero" placeholder="XXXX XXXX XXXX XXXX" maxlength="16">
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="expiry">Validade</label>
                                    <input type="text" id="expiry" name="cartao_validade" placeholder="MM/AA" maxlength="5">
                                </div>
                                <div class="form-group">
                                    <label for="cvv">CVV</label>
                                    <input type="text" id="cvv" name="cartao_cvv" placeholder="XXX" maxlength="3">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pix -->
                    <div id="pix" class="payment-option" style="display: none;">
                        <h3>Informações do Pix</h3>
                        <div class="pix-details">
                            <button type="button" class="pix-button" id="show-qr">Exibir QR Code</button>
                            <button type="button" class="pix-button" id="copy-code">Copiar código Pix</button>
                            <div class="qr-code" id="qr-code" style="display: none;">
                                <img src="https://via.placeholder.com/200x200.png?text=QR+Code" alt="QR Code">
                            </div>
                            <div class="copy-code" id="copy-code-text" style="display: none;">
                                <input type="text" value="<?= $chavePix; ?>" readonly>
                                <button type="button" onclick="copyToClipboard()">Copiar</button>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn-submit" id="finalizar-compra">Finalizar Pagamento</button>
                </div>
            </form>

            <aside class="summary-card">
                <div class="summary-body">
                    <h3>Resumo do Pedido</h3>

                    <?php foreach ($produtosCarrinho as $produto) : ?>
                        <p>
                            <?= $produto['quantidade_produtos']; ?>x <?= htmlspecialchars($produto['nome']); ?> 
                            <span class="price">R$ <?= number_format($produto['valor'], 2, ',', '.'); ?></span>
                        </p>
                    <?php endforeach; ?>

                    <hr>
                    <h4>Total <span class="total-price">R$ <?= number_format($totalCarrinho, 2, ',', '.'); ?></span></h4>
                </div>
            </aside>

        </div>
    </div>

    <script>
        function formatarTelefone(telefone) {
            return telefone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
        }

        document.getElementById('phone').addEventListener('input', function() {
            let telefone = this.value.replace(/\D/g, '');
            if (telefone.length <= 11) {
                this.value = formatarTelefone(telefone);
            }
        });

        document.getElementById("proximo").addEventListener("click", function() {
            if (document.getElementById("name").value && document.getElementById("email").value && document.getElementById("phone").value) {
                document.getElementById("etapa1").style.display = "none";
                document.getElementById("etapa2").style.display = "block";
                document.querySelector("header p").textContent = "Etapa 2: Método de Pagamento";
            } else {
                alert("Por favor, preencha todos os campos.");
            }
        });

        document.getElementById("pagamento-cartao").addEventListener("click", function() {
            document.getElementById("cartao").style.display = "block";
            document.getElementById("pix").style.display = "none";
            document.getElementById("cartao_hidden").value = "cartao";
            document.getElementById("pix_hidden").value = "";
        });

        document.getElementById("pagamento-pix").addEventListener("click", function() {
            document.getElementById("pix").style.display = "block";
            document.getElementById("cartao").style.display = "none";
            document.getElementById("pix_hidden").value = "pix";
            document.getElementById("cartao_hidden").value = "";
        });

        document.getElementById("show-qr").addEventListener("click", function() {
            document.getElementById("qr-code").style.display = "block";
            document.getElementById("copy-code-text").style.display = "none";
        });

        document.getElementById("copy-code").addEventListener("click", function() {
            document.getElementById("copy-code-text").style.display = "block";
            document.getElementById("qr-code").style.display = "none";
        });

        function copyToClipboard() {
            const copyText = document.getElementById("copy-code-text").querySelector("input");
            copyText.select();
            document.execCommand("copy");
            alert("Código Pix copiado!");
        }
    </script>
</body>
</html>
