<?php
session_start();
include_once("../bd/verificaLogin.php");
include_once("../bd/conexao.php");

$erro = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$nome_evento = $_POST['nome_evento'];
$descricao_evento = isset($_POST['descricao_evento']) ? $_POST['descricao_evento'] : '';
$data_evento = $_POST['data_evento'];
$hora_evento = $_POST['hora_evento'];
$cep_evento = isset($_POST['cep_evento']) ? trim($_POST['cep_evento']) : '';
$rua_evento = isset($_POST['rua_evento']) ? trim($_POST['rua_evento']) : '';
$complemento_evento = isset($_POST['complemento_evento']) ? trim($_POST['complemento_evento']) : '';
$bairro_evento = isset($_POST['bairro_evento']) ? trim($_POST['bairro_evento']) : '';
$localidade_evento = isset($_POST['localidade_evento']) ? trim($_POST['localidade_evento']) : '';
$estado_evento = isset($_POST['estado_evento']) ? trim($_POST['estado_evento']) : '';
$tipo_evento = $_POST['tipo_evento'];

    

    // Verificando se o organizador está autenticado
    if (isset($_SESSION['organizadores']['id_loginOrg'])) {
        $id_organizador = $_SESSION['organizadores']['id_loginOrg'];
    } else {
        die("Erro: Organizador não está autenticado.");
    }

    // Verificando e movendo o banner
    if (isset($_FILES['banner']) && $_FILES['banner']['error'] == 0) {
        $banner = $_FILES['banner'];
        $diretorio = '../imagens/banners/';
        
        $extensao = strtolower(pathinfo($banner['name'], PATHINFO_EXTENSION));
        if (!in_array($extensao, ['jpg', 'jpeg', 'png', 'gif'])) {
            die("Erro: Apenas arquivos JPEG, PNG ou GIF são permitidos.");
        }

        $banner_nome = uniqid() . '-' . basename($banner['name']);
        
        if (move_uploaded_file($banner['tmp_name'], $diretorio . $banner_nome)) {
            // Conectando ao banco de dados
            $connbanco = new banco();
            $conn = $connbanco->conectar();

            if ($conn) {
                // Inserindo o evento na tabela 'evento'
                $query = "INSERT INTO evento (nome_evento, descricao_evento, data_evento, hora_evento, cep_evento, rua_evento, complemento_evento, bairro_evento, localidade_evento, tipo_evento, estado_evento,  banner, id_loginOrg) 
          VALUES (:nome_evento, :descricao_evento, :data_evento, :hora_evento, :cep_evento, :rua_evento, :complemento_evento, :bairro_evento, :localidade_evento, :tipo_evento, :estado_evento, :banner, :id_loginOrg)";
$stmt = $conn->prepare($query);

// Bind dos parâmetros
$stmt->bindParam(':nome_evento', $nome_evento);
$stmt->bindParam(':descricao_evento', $descricao_evento);  // Garantir que a descrição seja vinculada corretamente
$stmt->bindParam(':data_evento', $data_evento);
$stmt->bindParam(':hora_evento', $hora_evento);
$stmt->bindParam(':cep_evento', $cep_evento);
$stmt->bindParam(':rua_evento', $rua_evento);
$stmt->bindParam(':complemento_evento', $complemento_evento);
$stmt->bindParam(':bairro_evento', $bairro_evento);
$stmt->bindParam(':localidade_evento', $localidade_evento);
$stmt->bindParam(':estado_evento', $estado_evento);
$stmt->bindParam(':tipo_evento', $tipo_evento);
$stmt->bindParam(':banner', $banner_nome);
$stmt->bindParam(':id_loginOrg', $id_organizador);


                // Executando a query
                if ($stmt->execute()) {
                    // Redirecionar para a página de festas do organizador
                    header("Location: ../organizador/festas.php");
                    exit(); // Termina a execução do script
                } else {
                    echo "Erro ao cadastrar evento.";
                }
            }
        } else {
            echo "Erro ao mover o banner.";
        }
    } else {
        echo "Erro: Banner não enviado.";
    }
}
?>
