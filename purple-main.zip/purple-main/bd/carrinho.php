<?php
include_once('../bd/conexao.php');

class Carrinho {
    private $conn;

    public function __construct() {
        $banco = new banco();
        $this->conn = $banco->conectar();
    }

    public function obterIdCarrinho($id_evento, $id_cadastro, $conn) {
        $query = "SELECT id_carrinho FROM carrinho WHERE id_evento = :id_evento AND id_cadastro = :id_cadastro";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id_evento', $id_evento);
        $stmt->bindParam(':id_cadastro', $id_cadastro);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$result) {
            error_log("Erro: Carrinho não encontrado para evento $id_evento e cliente $id_cadastro.");
            return null;
        }
        return $result['id_carrinho'];
    }

    public function obterIdCarrinhoProduto($id_carrinho, $conn) {
        $query = "SELECT id_carrinhoProd FROM carrinho_produtos WHERE id_carrinho = :id_carrinho";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id_carrinho', $id_carrinho);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$result) {
            error_log("Erro: Produtos não encontrados para carrinho $id_carrinho.");
            return null;
        }
        return $result['id_carrinhoProd'];
    }

    public function verificarCarrinhoExistente($id_evento, $id_cliente) {
        $query = "SELECT id_carrinho FROM carrinho WHERE id_evento = :id_evento AND id_cadastro = :id_cadastro";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_evento', $id_evento, PDO::PARAM_INT);
        $stmt->bindParam(':id_cadastro', $id_cliente, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    
function verificarProdutoNoCarrinho($idProduto) {
    global $connbanco;
    $query = "SELECT COUNT(*) FROM carrinho_produtos WHERE id_produto = :id_produto";
    $stmt = $connbanco->conectar()->prepare($query);
    $stmt->bindParam(':id_produto', $idProduto, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchColumn() > 0;  // Retorna verdadeiro se o produto estiver no carrinho
}

    public function calcularValorTotal($id_produto, $quantidade) {
        $query = "SELECT valor FROM produto WHERE id_produto = :id_produto";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_produto', $id_produto, PDO::PARAM_INT);
        $stmt->execute();
        $produto = $stmt->fetch(PDO::FETCH_ASSOC);

        return $produto['valor'] * $quantidade;
    }

    public function adicionarProdutoCarrinho($id_carrinho, $id_produto, $quantidade, $valor_total) {
        $query = "INSERT INTO carrinho_produtos (id_carrinho, id_produto, quantidade_produtos, valor_total) 
                  VALUES (:id_carrinho, :id_produto, :quantidade_produtos, :valor_total)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_carrinho', $id_carrinho, PDO::PARAM_INT);
        $stmt->bindParam(':id_produto', $id_produto, PDO::PARAM_INT);
        $stmt->bindParam(':quantidade_produtos', $quantidade, PDO::PARAM_INT);
        $stmt->bindParam(':valor_total', $valor_total, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function atualizarProdutoCarrinho($id_carrinho, $id_produto, $quantidade, $valor_total) {
        $query = "
            UPDATE carrinho_produtos 
            SET quantidade_produtos = quantidade_produtos + :quantidade_produtos, 
                valor_total = valor_total + :valor_total
            WHERE id_carrinho = :id_carrinho AND id_produto = :id_produto";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':quantidade_produtos', $quantidade, PDO::PARAM_INT);
        $stmt->bindParam(':valor_total', $valor_total, PDO::PARAM_STR);
        $stmt->bindParam(':id_carrinho', $id_carrinho, PDO::PARAM_INT);
        $stmt->bindParam(':id_produto', $id_produto, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function criarCarrinho($id_evento, $id_cliente) {
        $query = "INSERT INTO carrinho (id_evento, id_cadastro) VALUES (:id_evento, :id_cadastro)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_evento', $id_evento, PDO::PARAM_INT);
        $stmt->bindParam(':id_cadastro', $id_cliente, PDO::PARAM_INT);
        $stmt->execute();
        return $this->conn->lastInsertId();
    }
}
