<?php
include_once('../bd/conexao.php');

$connbanco = new banco(); // Objeto com os parâmetros da classe Banco

$connbanco->conectar(); // Tentará a conexão com o banco de dados

class User
{

    private $conn;

    public function __construct()
    {
        $conecta = new banco();
        $this->conn = $conecta->conectar();
    }

    public function verificaEmailIgual($email)
    {
        $sqlVerifica = "SELECT * FROM cadastro WHERE email = :email";
        $stmtVerifica = $this->conn->prepare($sqlVerifica);
        $stmtVerifica->bindParam(':email', $email);
        $stmtVerifica->execute();

        if ($stmtVerifica->rowCount() > 0) {
            return 1;
        } else {
            return 2;
        }
    }

    public function calculaIdade($data_nascimento)
    {
        $dataNascimento = new DateTime($data_nascimento);
        $dataAtual = new DateTime();
        $idade = $dataAtual->diff($dataNascimento)->y;

        return $idade;
    }

    public function criptografaSenha($senha)
    {
        return password_hash($senha, PASSWORD_DEFAULT);
    }

    public function insereDados()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            $telefone = $_POST['telefone'];
            $data_nascimento = $_POST['data_nascimento'];
            $senha = $_POST['senha'];
            $sexo = $_POST['sexo'];

            $idade = $this->calculaIdade($data_nascimento);
            $senhaCriptografada = $this->criptografaSenha($senha);

            $testeEmail = $this->verificaEmailIgual($email);

            if ($testeEmail == 1) {
                if (isset($_POST['cadastrar'])) {
                    $email = $_POST['email'];

                    $teste = new User();
                    $testar = $teste->verificaEmailIgual($email);

                    if ($testar == 1) {
                        $erro = 'Email já cadastrado no sistema!';
                        header("Location: ../cadastro/cadastro_org.php?erro=" . urlencode($erro));
                    }
                    
                }
            } else {
                try {
                    $sql = "INSERT INTO cadastro (nome, email, telefone, idade, sexo, senha) 
                                    VALUES (:nome, :email, :telefone, :idade, :sexo, :senha)";

                    $stmt = $this->conn->prepare($sql);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':telefone', $telefone);
                    $stmt->bindParam(':idade', $idade);
                    $stmt->bindParam(':sexo', $sexo);
                    $stmt->bindParam(':senha', $senhaCriptografada);

                    if ($stmt->execute()) {
                        header("Location: ../tela-inicial/tela-inicial.php");
                        exit();
                    } else {
                        header("Location: ../cadastro/cadastro_org.php");
                        exit();
                    }
                } catch (PDOException $e) {
                    echo "Erro: " . $e->getMessage();
                }
            }
        }

    }
}



$user = new User();
$user->insereDados();
