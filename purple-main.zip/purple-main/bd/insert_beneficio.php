<?php
session_start();
include_once("../bd/conexao.php");

if (!isset($_SESSION['id_evento'])) {
    die("Erro: Evento não identificado.");
}

$id_evento = $_SESSION['id_evento'];
unset($_SESSION['id_evento']); 

$connbanco = new banco();
$conn = $connbanco->conectar();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $produto_count = 1;

    while (isset($_POST["produto_nome_$produto_count"]) && !empty($_POST["produto_nome_$produto_count"])) {
        $nome_produto = $_POST["produto_nome_$produto_count"];
        $descricao_produto = $_POST["produto_descricao_$produto_count"];
        $valor_produto = $_POST["produto_valor_$produto_count"];
        $tipo_produto = $_POST["produto_tipo_$produto_count"];

        $query_produto = "INSERT INTO produto (nome, descricao, valor, tipo, id_evento) 
                          VALUES (:nome, :descricao, :valor, :tipo, :id_evento)";
        $stmt_produto = $conn->prepare($query_produto);

        $stmt_produto->bindParam(':nome', $nome_produto);
        $stmt_produto->bindParam(':descricao', $descricao_produto);
        $stmt_produto->bindParam(':valor', $valor_produto);
        $stmt_produto->bindParam(':tipo', $tipo_produto);
        $stmt_produto->bindParam(':id_evento', $id_evento);

        $stmt_produto->execute();
        $produto_count++;
    }

    header("Location: ../organizador/home.php");
    exit();
}
?>
