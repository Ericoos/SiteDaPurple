<?php
include_once('../bd/conexao.php');

class Festa
{
    private $nome_evento;
    private $descricao_evento;
    private $data_evento;
    private $hora_evento;
    private $cep_evento;
    private $rua_evento;
    private $complemento_evento;
    private $estado_evento;
    private $localidade_evento;
    private $banner;

    private $conn;

    public function __construct()
    {
        $conecta = new banco();
        $this->conn = $conecta->conectar();
    }

    
    public function salvarEvento($id_loginOrg)
    {
        $query = "INSERT INTO evento (nome_evento, descricao_evento, data_evento, hora_evento, cep_evento, rua_evento, complemento_evento, estado_evento, localidade_evento, banner, id_loginOrg)
                  VALUES (:nome_evento, :descricao_evento, :data_evento, :hora_evento, :cep_evento, :rua_evento, :complemento_evento, :localidade_evento, :banner, :id_loginOrg)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nome_evento', $this->nome_evento);
        $stmt->bindParam(':descricao_evento', $this->descricao_evento);
        $stmt->bindParam(':data_evento', $this->data_evento);
        $stmt->bindParam(':hora_evento', $this->hora_evento);
        $stmt->bindParam(':cep_evento', $this->cep_evento);
        $stmt->bindParam(':rua_evento', $this->rua_evento);
        $stmt->bindParam(':complemento_evento', $this->complemento_evento);
        $stmt->bindParam(':estado_evento', $this->estado_evento);
        $stmt->bindParam(':localidade_evento', $this->localidade_evento);
        $stmt->bindParam(':banner', $this->banner);
        $stmt->bindParam(':id_loginOrg', $id_loginOrg);

        return $stmt->execute();
    }

    
    public function buscarEventos($id_loginOrg)
    {
        $query = "SELECT * FROM evento WHERE id_loginOrg = :id_loginOrg";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_loginOrg', $id_loginOrg);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    

    
    public function buscarEventoPorId($id_evento)
    {
        $query = "SELECT * FROM evento WHERE id_evento = :id_evento";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_evento', $id_evento);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    
    public function buscarProdutosPorIdEvento($id_evento)
    {
        $query = "SELECT * FROM produto WHERE id_evento = :id_evento";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_evento', $id_evento);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    
    public function adicionarBeneficio($id_evento, $nome, $descricao, $valor, $quantidade, $tipo)
    {
        $query = "INSERT INTO produto (nome, descricao, valor, quantidade, quantidade_pfesta, tipo, id_evento) 
                  VALUES (:nome, :descricao, :valor, :quantidade, :quantidade_pfesta, :tipo, :id_evento)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':descricao', $descricao);
        $stmt->bindParam(':valor', $valor);
        $stmt->bindParam(':quantidade', $quantidade);
        $stmt->bindParam(':quantidade_pfesta', $quantidade);
        $stmt->bindParam(':tipo', $tipo);
        $stmt->bindParam(':id_evento', $id_evento);

        return $stmt->execute();
    }

    public function salvarProduto($id_evento, $nome, $valor, $quantidade, $tipo)
    {
    $query = "INSERT INTO produto (id_evento, nome, valor, quantidade, quantidade_pfesta, tipo) 
              VALUES (:id_evento, :nome, :valor, :quantidade, :quantidade_pfesta, :tipo)";
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':id_evento', $id_evento);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':valor', $valor);
    $stmt->bindParam(':quantidade', $quantidade);
    $stmt->bindParam(':quantidade_pfesta', $quantidade);
    $stmt->bindParam(':tipo', $tipo);

    $resultado = $stmt->execute();

    if ($resultado && $tipo === "ingresso") {
        $queryAtualiza = "UPDATE evento 
                          SET quantidade_ingresso = COALESCE(quantidade_ingresso, 0) + :quantidade 
                          WHERE id_evento = :id_evento";
        $stmtAtualiza = $this->conn->prepare($queryAtualiza);
        $stmtAtualiza->bindParam(':quantidade_pfesta', $quantidade);
        $stmtAtualiza->bindParam(':id_evento', $id_evento);
        $stmtAtualiza->execute();
    }

    return $resultado;
    }


    
    public function calcularQuantidadeIngressos($id_evento)
    {
    $query = "SELECT SUM(quantidade) AS total_ingressos 
              FROM produto 
              WHERE id_evento = :id_evento AND tipo = 'ingresso'";
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':id_evento', $id_evento);
    $stmt->execute();

    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    return $resultado['total_ingressos'] ?? 0;
    }



   
    public function atualizarBeneficio($id_produto, $nome, $descricao, $valor, $quantidade, $tipo)
    {
        $query = "UPDATE produto SET nome = :nome, descricao = :descricao, valor = :valor, quantidade = :quantidade, quantidade_pfesta = :quantidade_pfesta, tipo = :tipo WHERE id_produto = :id_produto";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_produto', $id_produto);
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':descricao', $descricao);
        $stmt->bindParam(':valor', $valor);
        $stmt->bindParam(':quantidade', $quantidade);
        $stmt->bindParam(':quantidade_pfesta', $quantidade);
        $stmt->bindParam(':tipo', $tipo);

        return $stmt->execute();
    }

    
    public function atualizaDadosFesta($id_loginOrg, $id_evento, $nome_evento, $descricao_evento, $data_evento, $hora_evento, $cep_evento, $rua_evento, $complemento_evento, $estado_evento, $banner)
{
    $query = "UPDATE evento 
              SET nome_evento = :nome_evento, 
                  descricao_evento = :descricao_evento, 
                  data_evento = :data_evento,
                  hora_evento = :hora_evento,  
                  cep_evento = :cep_evento, 
                  rua_evento = :rua_evento, 
                  complemento_evento = :complemento_evento, 
                  estado_evento = :estado_evento, 
                  banner = :banner 
              WHERE id_evento = :id_evento AND id_loginOrg = :id_loginOrg";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':nome_evento', $nome_evento);
    $stmt->bindParam(':descricao_evento', $descricao_evento);
    $stmt->bindParam(':data_evento', $data_evento);
    $stmt->bindParam(':hora_evento', $hora_evento);
    $stmt->bindParam(':cep_evento', $cep_evento);
    $stmt->bindParam(':rua_evento', $rua_evento);
    $stmt->bindParam(':complemento_evento', $complemento_evento);
    $stmt->bindParam(':estado_evento', $estado_evento);
    $stmt->bindParam(':banner', $banner);
    $stmt->bindParam(':id_evento', $id_evento);
    $stmt->bindParam(':id_loginOrg', $id_loginOrg);

    return $stmt->execute();
}

public function excluirEvento($id_evento)
{
    
    $query_produtos = "DELETE FROM produto WHERE id_evento = :id_evento";
    $stmt_produtos = $this->conn->prepare($query_produtos);
    $stmt_produtos->bindParam(':id_evento', $id_evento);
    $stmt_produtos->execute();

    $query_evento = "DELETE FROM evento WHERE id_evento = :id_evento";
    $stmt_evento = $this->conn->prepare($query_evento);
    $stmt_evento->bindParam(':id_evento', $id_evento);
    return $stmt_evento->execute();
}


public function getDataEvento($idEvento) {

    $sql = "SELECT data_evento FROM evento WHERE id_evento = :id_evento";
    $stmt = $this->conn->prepare($sql);
    $stmt->bindParam(':id_evento', $idEvento);
    $stmt->execute();
    
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    return $resultado ? $resultado['data_evento'] : false;
}


public function verificarStatusFesta($idEvento) {
    $query = "SELECT data_evento, hora_evento FROM evento WHERE id_evento = :id_evento";
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':id_evento', $idEvento, PDO::PARAM_INT);
    $stmt->execute();


    if ($stmt->rowCount() > 0) {
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $dataEvento = $result['data_evento'];
        $horaEvento = $result['hora_evento'];
        $dataAtual = date('Y-m-d'); 
        $horaAtual = date('H:i');   

        if ($dataEvento > $dataAtual || ($dataEvento == $dataAtual && $horaEvento >= $horaAtual)) {
            return 'ativa';
        } else {
            return 'inativa';
        }
    } else {
        return null; 
    }
}
}
?>
