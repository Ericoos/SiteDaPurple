<?php
include_once('../bd/conexao.php');

class Organizador
{
    private $conn;

    public function __construct()
    {
        $conecta = new banco();
        $this->conn = $conecta->conectar();
    }

    // Método para obter os dados do organizador
    public function pegaDadosOrg($id_loginOrg)
    {
        $query = "SELECT nome_organizador, descricao_organizador, email_contato, email_organizador, imagem_perfil, telefone_organizador, chave_pix, senha_organizador FROM login_organizador WHERE id_loginOrg = :id_loginOrg";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_loginOrg', $id_loginOrg);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            return false;
        }
    }

    // Método para atualizar os dados do organizador
    public function atualizarPerfilOrganizador(
        $id_loginOrg, 
        $nome_organizador, 
        $descricao_organizador, 
        $email_contato, 
        $email_organizador, 
        $telefone_organizador, 
        $chave_pix, 
        $senha_organizador, 
        $imagem_perfil = null
    ) {
        $query = "UPDATE login_organizador SET 
                    nome_organizador = :nome_organizador,
                    descricao_organizador = :descricao_organizador,
                    email_contato = :email_contato,
                    email_organizador = :email_organizador,
                    telefone_organizador = :telefone_organizador,
                    chave_pix = :chave_pix";
    
        if ($senha_organizador) {
            $senha_organizador = password_hash($senha_organizador, PASSWORD_DEFAULT);
            $query .= ", senha_organizador = :senha_organizador";
        }
    
        if ($imagem_perfil) {
            $query .= ", imagem_perfil = :imagem_perfil";
        }
    
        $query .= " WHERE id_loginOrg = :id_loginOrg";
    
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nome_organizador', $nome_organizador);
        $stmt->bindParam(':descricao_organizador', $descricao_organizador);
        $stmt->bindParam(':email_contato', $email_contato);
        $stmt->bindParam(':email_organizador', $email_organizador);
        $stmt->bindParam(':telefone_organizador', $telefone_organizador);
        $stmt->bindParam(':chave_pix', $chave_pix);
        $stmt->bindParam(':id_loginOrg', $id_loginOrg);
    
        if ($senha_organizador) {
            $stmt->bindParam(':senha_organizador', $senha_organizador);
        }
    
        if ($imagem_perfil) {
            $stmt->bindParam(':imagem_perfil', $imagem_perfil);
        }
    
        return $stmt->execute();
    }
    

    // Método para login do organizador
    public function loginOrg($email_organizador, $senha_organizador)
    {
        $query = "SELECT * FROM login_organizador WHERE email_organizador = :email_organizador";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email_organizador', $email_organizador);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $organizador = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($senha_organizador, $organizador['senha_organizador'])) {
                return ['tipo' => 'organizador', 'usuario' => $organizador];
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    // Método para excluir o organizador
    public function excluirOrganizador($id_loginOrg)
    {
        try {
            $query = "DELETE FROM login_organizador WHERE id_loginOrg = :id_loginOrg";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id_loginOrg', $id_loginOrg);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    // Método para inserir um novo organizador
    public function inserirOrganizador($nome, $descricao, $imagem_perfil, $email, $email_contato, $telefone, $senha, $chave_pix)
    {
        // Se a descrição não for fornecida, atribui uma descrição padrão
        if (empty($descricao)) {
            $descricao = 'Adicione aqui sua descrição'; // Descrição padrão
        }

        // Verifica se o email já está cadastrado
        $stmt = $this->conn->prepare("SELECT * FROM login_organizador WHERE email_organizador = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo "Email já cadastrado!";
        } else {
            $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);

            // Se a imagem de perfil for fornecida, move para o diretório de imagens
            if ($imagem_perfil) {
                $imagemPath = "../imagens/perfis/" . basename($imagem_perfil);
                move_uploaded_file($_FILES['imagem_perfil']['tmp_name'], $imagemPath);
            }

            // Insere o novo organizador no banco de dados
            $stmt = $this->conn->prepare("INSERT INTO login_organizador 
                (nome_organizador, descricao_organizador, imagem_perfil, email_organizador, email_contato, telefone_organizador, senha_organizador, chave_pix)
                VALUES (:nome, :descricao, :imagem_perfil, :email, :email_contato, :telefone, :senha, :chave_pix)");

            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':descricao', $descricao);
            $stmt->bindParam(':imagem_perfil', $imagem_perfil);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':email_contato', $email_contato);
            $stmt->bindParam(':telefone', $telefone);
            $stmt->bindParam(':senha', $senhaCriptografada);
            $stmt->bindParam(':chave_pix', $chave_pix);

            if ($stmt->execute()) {
                header("Location: ../login/login.php");
                exit();
            } else {
                echo "Erro ao cadastrar organizador.";
            }
        }
    }
}

// Verifica se o formulário foi enviado
if (isset($_POST['cadastrar'])) {
    if (isset($_POST['nome_organizador'], $_POST['email_organizador'], $_POST['email_contato'], $_POST['telefone_organizador'], $_POST['senha_organizador'], $_FILES['imagem_perfil'])) {
        // Passando os valores para a função de inserção
        $organizador = new Organizador();
        $organizador->inserirOrganizador(
            $_POST['nome_organizador'],
            $_POST['descricao_organizador'], 
            $_FILES['imagem_perfil']['name'],  
            $_POST['email_organizador'],
            $_POST['email_contato'],
            $_POST['telefone_organizador'],
            $_POST['senha_organizador'],
            $_POST['chave_pix']
        );
    }
}

// Lógica de login
if (isset($_POST['login'])) {
    if (isset($_POST['email_organizador']) && isset($_POST['senha_organizador'])) {
        $email_organizador = $_POST['email_organizador'];
        $senha_organizador = $_POST['senha_organizador'];
        $resultadoLogin = $organizador->loginOrg($email_organizador, $senha_organizador);

        if ($resultadoLogin) {
            echo "Login bem-sucedido! Bem-vindo, " . $resultadoLogin['usuario']['nome_organizador'];
        }
    }
}
?>
