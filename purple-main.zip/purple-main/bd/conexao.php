<?php

class banco { 
    private $usuario = 'root';
    private $senha =  '';
    private $database = 'purple_db';
    private $host = 'localhost';
    public $conn; 
    public function conectar() { 
        try {
            $this->conn = new PDO("mysql:host=$this->host;dbname=$this->database", $this->usuario, $this->senha);
            return $this->conn; 
        } catch (PDOException $e) {
            return false;
        }
    }
}

?>