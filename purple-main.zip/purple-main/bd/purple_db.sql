-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 28-Nov-2024 às 12:14
-- Versão do servidor: 5.7.33
-- versão do PHP: 8.0.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `purple_db`
--
CREATE DATABASE IF NOT EXISTS `purple_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `purple_db`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `addnomecliente`
--

CREATE TABLE IF NOT EXISTS `addnomecliente` (
  `id_addNomeCliente` int(11) NOT NULL AUTO_INCREMENT,
  `id_evento` int(11) DEFAULT NULL,
  `id_produto` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `nome_cliente` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_addNomeCliente`),
  KEY `id_evento` (`id_evento`),
  KEY `id_produto` (`id_produto`),
  KEY `id_cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro`
--

CREATE TABLE IF NOT EXISTS `cadastro` (
  `id_cadastro` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `sexo` varchar(10) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_cadastro`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cadastro`
--

INSERT INTO `cadastro` (`id_cadastro`, `nome`, `email`, `telefone`, `sexo`, `idade`, `senha`) VALUES
(1, 'Cliente', 'cliente@gmail.com', '(11) 96718-8305', 'masculino', 18, '$2y$10$Nd5Oi7572k84jcA25iLuve8VplvDWTfeEQxtvjfbd20zBLA/9pxkK');

-- --------------------------------------------------------

--
-- Estrutura da tabela `carrinho`
--

CREATE TABLE IF NOT EXISTS `carrinho` (
  `id_carrinho` int(11) NOT NULL AUTO_INCREMENT,
  `id_cadastro` int(11) DEFAULT NULL,
  `id_evento` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_carrinho`),
  KEY `id_cliente` (`id_cadastro`),
  KEY `fk_carrinho_evento` (`id_evento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `carrinho`
--

INSERT INTO `carrinho` (`id_carrinho`, `id_cadastro`, `id_evento`) VALUES
(1, NULL, 25),
(2, NULL, 25),
(3, NULL, 26),
(4, NULL, 25);

-- --------------------------------------------------------

--
-- Estrutura da tabela `carrinho_produtos`
--

CREATE TABLE IF NOT EXISTS `carrinho_produtos` (
  `id_carrinhoProd` int(11) NOT NULL AUTO_INCREMENT,
  `id_carrinho` int(11) DEFAULT NULL,
  `id_produto` int(11) DEFAULT NULL,
  `quantidade_produtos` int(11) DEFAULT NULL,
  `valor_carrinho` int(11) NOT NULL,
  PRIMARY KEY (`id_carrinhoProd`),
  KEY `id_carrinho` (`id_carrinho`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `evento`
--

CREATE TABLE IF NOT EXISTS `evento` (
  `id_evento` int(11) NOT NULL AUTO_INCREMENT,
  `nome_evento` varchar(255) DEFAULT NULL,
  `quantidade_ingresso` varchar(255) DEFAULT NULL,
  `descricao_evento` varchar(500) DEFAULT NULL,
  `data_evento` date DEFAULT NULL,
  `hora_evento` time NOT NULL,
  `cep_evento` varchar(255) NOT NULL,
  `rua_evento` varchar(255) NOT NULL,
  `complemento_evento` varchar(255) NOT NULL,
  `bairro_evento` varchar(255) NOT NULL,
  `localidade_evento` varchar(255) NOT NULL,
  `estado_evento` varchar(255) NOT NULL,
  `id_loginOrg` int(11) DEFAULT NULL,
  `banner` varchar(255) NOT NULL,
  PRIMARY KEY (`id_evento`),
  KEY `id_loginOrg` (`id_loginOrg`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `evento`
--

INSERT INTO `evento` (`id_evento`, `nome_evento`, `quantidade_ingresso`, `descricao_evento`, `data_evento`, `hora_evento`, `cep_evento`, `rua_evento`, `complemento_evento`, `bairro_evento`, `localidade_evento`, `estado_evento`, `id_loginOrg`, `banner`) VALUES
(3, 'teste 2', '', 'a', '2024-11-14', '15:00:00', '04230-000', 'Avenida Almirante Delamare', 'lado par', 'Cidade Nova HeliÃ³polis', 'SÃ£o Paulo', 'SP', 3, '672e2bbbbbe1a-riohostel.png'),
(5, 'evento novo com protudot', '', 'we321312', '2024-11-20', '00:00:00', '04230-000', 'Avenida Almirante Delamare', 'lado par', 'Cidade Nova Heliópolis', 'São Paulo', 'SP', 3, '673e2e8f1c480-image (1).png'),
(6, 'Festa teste 242', '', '2424', '2024-11-20', '00:00:00', '04230-000', 'Avenida Almirante Delamare', 'lado par', 'Cidade Nova Heliópolis', 'São Paulo', 'SP', 3, '673e30e9204a3-image (1).png'),
(7, 'Festa teste 242', '', '2424', '2024-11-20', '00:00:00', '04230-000', 'Avenida Almirante Delamare', 'lado par', 'Cidade Nova Heliópolis', 'São Paulo', 'SP', 3, '673e30f6db5fb-image (1).png'),
(25, 'evento novo para exibir', '', 'Descrição do evento que aparece na ', '2024-11-30', '20:30:00', '04230-000', 'Avenida Almirante Delamare', 'Na mesma calçada o Gula Bar', 'Cidade Nova Heliópolis', 'São Paulo', 'SP', 3, '6744f4543d8fb-Captura de tela 2024-09-15 003845.png'),
(26, 'Natal', NULL, 'Natal dos Guri pós TCC muito massa e os krlh4 puta de graça', '2024-12-25', '22:00:00', '04230-000', 'Avenida Almirante Delamare', 'lado par', 'Cidade Nova Heliópolis', 'São Paulo', 'SP', 3, '67478cc9538d2-WhatsApp Image 2024-11-11 at 20.45.16.jpeg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `historicoeventos`
--

CREATE TABLE IF NOT EXISTS `historicoeventos` (
  `id_historico` int(11) NOT NULL AUTO_INCREMENT,
  `evento_id` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_historico`),
  KEY `evento_id` (`evento_id`),
  KEY `id_cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `login_administrador`
--

CREATE TABLE IF NOT EXISTS `login_administrador` (
  `id_loginAdm` int(11) NOT NULL AUTO_INCREMENT,
  `senha` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_loginAdm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `login_organizador`
--

CREATE TABLE IF NOT EXISTS `login_organizador` (
  `id_loginOrg` int(11) NOT NULL AUTO_INCREMENT,
  `senha_organizador` varchar(255) DEFAULT NULL,
  `nome_organizador` varchar(255) DEFAULT NULL,
  `email_organizador` varchar(255) DEFAULT NULL,
  `telefone_organizador` varchar(20) DEFAULT NULL,
  `email_contato` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_loginOrg`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `login_organizador`
--

INSERT INTO `login_organizador` (`id_loginOrg`, `senha_organizador`, `nome_organizador`, `email_organizador`, `telefone_organizador`, `email_contato`) VALUES
(3, '$2y$10$8qw2ZzPnnShWTZ9P8gIYLOV94gp7BUkvE.wylhc.XuteMtOIsc8CS', 'André Kauã Leal Pereira', 'organizador@gmail.com', '(11) 95382-7857', 'contatoorganizador@gmail.com'),
(4, '$2y$10$sA6Ht2V4dacX71OBRGL0GO/tDhsMu.r4sBm74Nzf17DgLk9NeQ9OG', 'Organizador 2', 'organizador2@gmail.com', '(11) 95382-7857', 'contatoorganizador2@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

CREATE TABLE IF NOT EXISTS `pagamento` (
  `id_pagamento` int(11) NOT NULL AUTO_INCREMENT,
  `forma_pagamento` varchar(50) DEFAULT NULL,
  `data_pagamento` date DEFAULT NULL,
  `status_compra` varchar(50) DEFAULT NULL,
  `carrinho_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_pagamento`),
  KEY `carrinho_id` (`carrinho_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `participacaoevento`
--

CREATE TABLE IF NOT EXISTS `participacaoevento` (
  `id_participacao` int(11) NOT NULL AUTO_INCREMENT,
  `id_evento` int(11) DEFAULT NULL,
  `id_cadastro` int(11) DEFAULT NULL,
  `id_pagamento` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_participacao`),
  KEY `evento_id` (`id_evento`),
  KEY `id_cliente` (`id_cadastro`),
  KEY `pagamento_id` (`id_pagamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE IF NOT EXISTS `produto` (
  `id_produto` int(11) NOT NULL AUTO_INCREMENT,
  `id_evento` int(11) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `valor` varchar(255) DEFAULT NULL,
  `quantidade` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_produto`),
  KEY `id_evento` (`id_evento`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id_produto`, `id_evento`, `nome`, `tipo`, `descricao`, `valor`, `quantidade`) VALUES
(5, 5, 'cachaça', 'beneficio', 'Cachaça', '34', '35'),
(6, 7, 'cachaça', '2444', 'Cachaça', '2', '2'),
(27, 5, 'beneficio novo', 'beneficio', '2323', '2323', ''),
(28, 5, 'beneficio novo', 'beneficio', '2323', '2323', ''),
(29, 5, 'beneficio novo', 'beneficio', '2323', '2323', ''),
(30, 5, 'beneficio novo', 'beneficio', '2323', '2323', ''),
(31, 5, 'beneficio novo', 'beneficio', '2323', '2323', ''),
(32, 5, 'beneficio novo', 'beneficio', '2323', '2323', ''),
(33, 5, 'beneficio novo', 'beneficio', '2323', '2323', '67'),
(59, 25, 'Beneficio', 'beneficio', 'Beneficios desc', '23', '40'),
(60, 25, 'Ingresso camarote', 'ingresso', 'Da acesso ao camarote', '50', '5'),
(61, 25, 'Ingresso vip', 'ingresso', 'vip', '300', '600'),
(63, 25, 'Camarote novo', 'ingresso', '240', '240', '10'),
(64, 26, 'Cadastrar novo ingresso', 'ingresso', 'ingresso natal', '25', '200');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos_evento`
--

CREATE TABLE IF NOT EXISTS `produtos_evento` (
  `id_prodEventos` int(11) NOT NULL AUTO_INCREMENT,
  `id_evento` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `id_produto` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_prodEventos`),
  KEY `id_evento` (`id_evento`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `addnomecliente`
--
ALTER TABLE `addnomecliente`
  ADD CONSTRAINT `addnomecliente_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `addnomecliente_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`),
  ADD CONSTRAINT `addnomecliente_ibfk_3` FOREIGN KEY (`id_cliente`) REFERENCES `cadastro` (`id_cadastro`);

--
-- Limitadores para a tabela `carrinho`
--
ALTER TABLE `carrinho`
  ADD CONSTRAINT `carrinho_ibfk_1` FOREIGN KEY (`id_cadastro`) REFERENCES `cadastro` (`id_cadastro`),
  ADD CONSTRAINT `fk_carrinho_evento` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `carrinho_produtos`
--
ALTER TABLE `carrinho_produtos`
  ADD CONSTRAINT `carrinho_produtos_ibfk_1` FOREIGN KEY (`id_carrinho`) REFERENCES `carrinho` (`id_carrinho`),
  ADD CONSTRAINT `carrinho_produtos_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`);

--
-- Limitadores para a tabela `evento`
--
ALTER TABLE `evento`
  ADD CONSTRAINT `evento_ibfk_1` FOREIGN KEY (`id_loginOrg`) REFERENCES `login_organizador` (`id_loginOrg`);

--
-- Limitadores para a tabela `historicoeventos`
--
ALTER TABLE `historicoeventos`
  ADD CONSTRAINT `historicoeventos_ibfk_1` FOREIGN KEY (`evento_id`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `historicoeventos_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `cadastro` (`id_cadastro`);

--
-- Limitadores para a tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `pagamento_ibfk_1` FOREIGN KEY (`carrinho_id`) REFERENCES `carrinho` (`id_carrinho`);

--
-- Limitadores para a tabela `participacaoevento`
--
ALTER TABLE `participacaoevento`
  ADD CONSTRAINT `participacaoevento_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `participacaoevento_ibfk_2` FOREIGN KEY (`id_cadastro`) REFERENCES `cadastro` (`id_cadastro`),
  ADD CONSTRAINT `participacaoevento_ibfk_3` FOREIGN KEY (`id_pagamento`) REFERENCES `pagamento` (`id_pagamento`);

--
-- Limitadores para a tabela `produto`
--
ALTER TABLE `produto`
  ADD CONSTRAINT `produto_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`);

--
-- Limitadores para a tabela `produtos_evento`
--
ALTER TABLE `produtos_evento`
  ADD CONSTRAINT `produtos_evento_ibfk_1` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`),
  ADD CONSTRAINT `produtos_evento_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
