<?php
session_start();
include('../bd/conexao.php');
include_once('../bd/carrinho.php');

if (!isset($_SESSION['clientes'])) {
    header("Location: ../login.php");
    exit;
}

$id_cadastro = $_SESSION['clientes'];
$id_evento = $_POST['id_evento'] ?? null;
$id_carrinho = $_POST['id_carrinho'] ?? null;
$id_carrinhoProd = $_POST['id_carrinhoProd'] ?? null;

if (!$id_evento || !$id_carrinho || !$id_carrinhoProd) {
    echo "Erro: Informações do carrinho ou evento estão incompletas.";
    exit;
}

$nome_pagamento = $_POST['nome_pagamento'] ?? null;
$email_pagamento = $_POST['email_pagamento'] ?? null;
$telefone_pagamento = $_POST['telefone_pagamento'] ?? null;
$metodo_pagamento = isset($_POST['cartao_nome']) ? 'cartao' : 'pix';

if (empty($nome_pagamento) || empty($email_pagamento) || empty($telefone_pagamento)) {
    echo "Erro: Todos os campos de pagamento devem ser preenchidos.";
    exit;
}

try {
    $connbanco = new banco();
    $conn = $connbanco->conectar();

    // Buscar o valor_total da tabela 'carrinho_produtos' 
    $queryCarrinho = "SELECT SUM(valor_total) as total FROM carrinho_produtos WHERE id_carrinho = :id_carrinho";
    $stmtCarrinho = $conn->prepare($queryCarrinho);
    $stmtCarrinho->bindParam(':id_carrinho', $id_carrinho, PDO::PARAM_INT);
    $stmtCarrinho->execute();
    $resultCarrinho = $stmtCarrinho->fetch(PDO::FETCH_ASSOC);

    $valor_total = $resultCarrinho['total'];

    // Inserir pagamento na tabela 'pagamento'
    $queryPagamento = "INSERT INTO pagamento 
        (id_cadastro, id_evento, id_carrinho, id_carrinhoProd, nome_pagamento, email_pagamento, telefone_pagamento, forma_pagamento, data_pagamento, status_compra, valor_totalpag) 
        VALUES 
        (:id_cadastro, :id_evento, :id_carrinho, :id_carrinhoProd, :nome_pagamento, :email_pagamento, :telefone_pagamento, :forma_pagamento, CURRENT_TIMESTAMP, 'Finalizado', :valor_totalpag)";
    
    $stmt = $conn->prepare($queryPagamento);
    $stmt->bindParam(':id_cadastro', $id_cadastro);
    $stmt->bindParam(':id_evento', $id_evento);
    $stmt->bindParam(':id_carrinho', $id_carrinho);
    $stmt->bindParam(':id_carrinhoProd', $id_carrinhoProd);
    $stmt->bindParam(':nome_pagamento', $nome_pagamento);
    $stmt->bindParam(':email_pagamento', $email_pagamento);
    $stmt->bindParam(':telefone_pagamento', $telefone_pagamento);
    $stmt->bindParam(':forma_pagamento', $metodo_pagamento);
    $stmt->bindParam(':valor_totalpag', $valor_total);  // Atribuindo o valor total da compra
    $stmt->execute();

    // Capturar o id do pagamento gerado
    $id_pagamento = $conn->lastInsertId();

    // Inserir na tabela 'participacaoevento'
    $queryParticipacao = "INSERT INTO participacaoevento (id_evento, id_cadastro, id_pagamento) 
                          VALUES (:id_evento, :id_cadastro, :id_pagamento)";
    $stmtParticipacao = $conn->prepare($queryParticipacao);
    $stmtParticipacao->bindParam(':id_evento', $id_evento);
    $stmtParticipacao->bindParam(':id_cadastro', $id_cadastro);
    $stmtParticipacao->bindParam(':id_pagamento', $id_pagamento);
    $stmtParticipacao->execute();

    // Redirecionar para a página de sucesso
    header("Location: ../carteira/carteira.php");
    exit;
} catch (PDOException $e) {
    echo "Erro ao processar pagamento: " . $e->getMessage();
}
?>
