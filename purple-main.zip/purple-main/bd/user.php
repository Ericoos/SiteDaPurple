<?php 
include_once('../bd/conexao.php');

class Usuario
{
    private $conn;

    public function __construct()
    {
        $conecta = new banco();
        $this->conn = $conecta->conectar();
    }

    public function pegarDadosCliente($id_cadastro)
    {
        $query = "SELECT id_cadastro, nome, email, telefone, idade, senha FROM cadastro WHERE id_cadastro = :id_cadastro";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_cadastro', $id_cadastro);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
    }

    public function atualizarPerfilUsuario($id_cadastro, $nome, $email, $telefone, $idade, $senha = null)
{
    $query = "UPDATE cadastro SET nome = :nome, email = :email, telefone = :telefone, idade = :idade";

    // Se a senha foi fornecida, adicionamos a cláusula de atualização para senha
    if ($senha) {
        $query .= ", senha = :senha"; 
    }

    $query .= " WHERE id_cadastro = :id_cadastro";

    $stmt = $this->conn->prepare($query);

    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':telefone', $telefone);
    $stmt->bindParam(':idade', $idade);
    $stmt->bindParam(':id_cadastro', $id_cadastro);

    // Se a senha foi fornecida, deve ser passada na bindParam
    if ($senha) {
        $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT); // Criptografa a nova senha
        $stmt->bindParam(':senha', $senhaCriptografada);
    }

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}


    public function loginUser($email, $senha)
    {
        $query = "SELECT * FROM cadastro WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($senha, $usuario['senha'])) {
                return ['tipo' => 'cliente', 'usuario' => $usuario];
            }
        }
        return false;
    }

    public function insereUsuario($nome, $email, $telefone, $dataNascimento, $senha, $sexo)
    {
        if ($this->verificaEmailIgual($email)) {
            header("Location: ../cadastro/cadastro_org.php?erro=" . urlencode('Email já cadastrado no sistema!'));
            exit;
        }

        $idade = $this->calculaIdade($dataNascimento);
        $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);

        $query = "INSERT INTO cadastro (nome, email, telefone, idade, sexo, senha)
                  VALUES (:nome, :email, :telefone, :idade, :sexo, :senha)";

        try {
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':telefone', $telefone);
            $stmt->bindParam(':idade', $idade);
            $stmt->bindParam(':sexo', $sexo);
            $stmt->bindParam(':senha', $senhaCriptografada);

            if ($stmt->execute()) {
                header("Location: ../tela-inicial/tela-inicial.php");
                exit;
            } else {
                header("Location: ../cadastro/cadastro_org.php");
                exit;
            }
        } catch (PDOException $e) {
            echo "Erro: " . $e->getMessage();
            exit;
        }
    }

    public function verificaEmailIgual($email)
    {
        $query = "SELECT * FROM cadastro WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }

    public function calculaIdade($dataNascimento)
    {
        $dataNasc = new DateTime($dataNascimento);
        $dataAtual = new DateTime();
        return $dataAtual->diff($dataNasc)->y;
    }
}

$usuario = new Usuario();
if (isset($_POST['cadastrar'])) {
    if (isset($_POST['nome'], $_POST['email'], $_POST['telefone'], $_POST['dataNascimento'], $_POST['senha'], $_POST['sexo'])) {

        $usuario->insereUsuario(
            $_POST['nome'],
            $_POST['email'],
            $_POST['telefone'],
            $_POST['dataNascimento'],
            $_POST['senha'],
            $_POST['sexo']
        );
    } else {
        header("Location: ../cadastro/cadastro_org.php?erro=" . urlencode('Erro ao inserir dados'));
        exit;
    }
}
?>
