<?php
include('../bd/organizador.php');
include('../bd/user.php');
session_start();

$erro = '';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $usuario = new Usuario();
    $loginInfoCliente = $usuario->loginUser($email, $senha);

    if ($loginInfoCliente) {
        $_SESSION['login'] = true;
        $_SESSION['clientes'] = $loginInfoCliente['usuario']['id_cadastro'];
        header("Location: ../tela-inicial/tela-inicial.php");
        exit();
    }

    $organizador = new Organizador();
    $loginInfoOrganizador = $organizador->loginOrg($email, $senha);

    if ($loginInfoOrganizador) {
        $_SESSION['login'] = true;
        $_SESSION['organizadores'] = [
            'id_loginOrg' => $loginInfoOrganizador['usuario']['id_loginOrg'],
            'nome_organizador' => $loginInfoOrganizador['usuario']['nome_organizador']
        ];
        header("Location: ../organizador/festas.php");
        exit();
    }

    $erro = 'Email ou senha incorretos!';
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>Login</title>
</head>

<body>

    <div class="area">

        <form action="login.php" method="POST">

            <img class="logo" width="250" height="130" src="../imagens/logo-roxo2.png" alt="logo">

            <h1 class="logintxt">Realize seu Login</h1>

            <div class="email-txt">
                <p>Email</p>
            </div>

            <div class="email">
                <input placeholder="Email" name="email" type="email" required>
            </div>

            <div class="senha-txt">
                <p>Senha</p>
            </div>

            <div class="senha">
                <input placeholder="Senha" name="senha" id="password" type="password">
            </div>

            <div class="mostrar-senha">
                Mostrar senha <input class="caixa" type="checkbox" id="togglePassword">
                <a class="esqueci-a-senha" href="#">Esqueci minha senha</a>
            </div>

            <?php if (!empty($erro)): ?>
                <p style="color:red;"><?php echo $erro; ?></p>
            <?php endif; ?>

            <button class="botao" type="submit" name="login">Entrar</button>

            <div class="cadastra-se">
                <p>Não tem uma conta? <a href="../cadastro/cadastro_org.php">Cadastre-se</a></p>
            </div>

        </form>

    </div>

    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('change', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
        });
    </script>
</body>

</html>