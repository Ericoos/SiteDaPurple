<?php
include_once("../bd/conexao.php");
include_once("../bd/user.php");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$usuario = new Usuario();
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['nome'], $_POST['email'], $_POST['telefone'], $_POST['dataNascimento'], $_POST['senha'], $_POST['sexo'])) {

        $usuario->insereUsuario(
            $_POST['nome'],
            $_POST['email'],
            $_POST['telefone'],
            $_POST['dataNascimento'],
            $_POST['senha'],
            $_POST['sexo']
        );
    } else {
        header("Location: ../cadastro/cadastro_org.php?erro=" . urlencode('Preencha todos os campos obrigatórios!'));
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cadastro.css">
    <title>Cadastro</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#telefone").on("input", function() {
                var telefone = $(this).val();
                telefone = telefone.replace(/\D/g, "");
                telefone = telefone.replace(/^(\d{2})(\d)/g, "($1) $2");
                telefone = telefone.replace(/(\d)(\d{4})$/, "$1-$2");
                $(this).val(telefone);
            });
        });
    </script>
</head>

<body>
    <div class="area">
        <form action="../bd/user.php" method="POST" class="form">

            <img class="logo" width="250" height="130" src="../imagens/logo-roxo2.png" alt="logo">

            <h1 class="cadastrotxt">Realize seu Cadastro</h1>

                <div class="nome-txt">
                    <p>Nome Completo:</p>
                </div>
                <div class="nome">
                    <input placeholder="Nome completo" name="nome" required type="text" maxlength="256">
                </div>

                <div class="email-txt">
                    <p>Email:</p>
                </div>
                <div class="email">
                    <input placeholder="Email" name="email" required type="email" maxlength="256">
                </div>

                <div class="telefone-txt">
                    <p>Telefone:</p>
                </div>
                <div class="telefone">
                    <input placeholder="(00) 00000-0000" name="telefone" required type="tel" id="telefone" maxlength="15">
                </div>

                <div class="data-de-nascimento-txt">
                    <p>Data De Nascimento:</p>
                </div>
                <div class="data-de-nascimento">
                    <input name="dataNascimento" required type="date">
                </div>

                <div class="senha-txt">
                    <p>Senha:</p>
                </div>
                <div class="senha">
                    <input placeholder="Senha" name="senha" id="password" type="password" required>
                </div>

                <div class="mostrar-senha">
                    Mostrar senha<input class="caixa" type="checkbox" id="togglePassword">
                </div>


                <div class="sexo">
                    <p>Sexo:</p>
                    <label>
                        <input class="caixa" type="radio" name="sexo" value="masculino" required> Masculino
                    </label>
                    <label>
                        <input class="caixa" type="radio" name="sexo" value="feminino" required> Feminino
                    </label>
                </div>

                <div style="text-align: center;" class="termos">
                    <p>Ao se cadastrar, você concorda com nossos 
                        <a href="../termos/termos_de_serviço.html">Termos de serviço,
                        <a href="../termos/termos_de_uso.html"> Termos de uso,
                        <a href="../termos/politica_de_privacidade.html"> Política de Privacidade.</a>
                    </p>
                </div>

                <button class="botao" type="submit" name="cadastrar">
                    Registrar
                </button>

                <a href="../login/login.php">
                    <button class="botao" type="button">Voltar</button>
                </a>
        </form>
    </div>

    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('change', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
        });
    </script>
</body>

</html>