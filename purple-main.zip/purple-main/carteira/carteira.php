<?php
session_start();
include_once('../bd/conexao.php');
include_once('../bd/festa.php');

$connbanco = new banco();
$connbanco->conectar();

// Verifica se o usuário está logado
if (isset($_SESSION['clientes'])) { // Use a chave correta para o ID do usuário
    $userId = $_SESSION['clientes'];
} else {
    echo "Usuário não autenticado!";
    exit;
}

// Consulta os pagamentos finalizados para o usuário
$query = "
    SELECT p.id_pagamento, p.id_evento, p.data_pagamento, e.nome_evento, e.data_evento, e.localidade_evento
    FROM pagamento p
    JOIN evento e ON p.id_evento = e.id_evento
    WHERE p.id_cadastro = :id_cadastro AND p.status_compra = 'Finalizado'
";
$stmt = $connbanco->conectar()->prepare($query);
$stmt->bindParam(':id_cadastro', $userId, PDO::PARAM_INT);
$stmt->execute();

$pagamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carteira</title>
    <link rel="stylesheet" href="carteira.css">
    <link rel="stylesheet" href="../detalhes/cabeçalho.css">
    <link rel="stylesheet" href="../detalhes/rodape.css">
</head>

<body>
    <header id="header"></header>

    <main class="cliente">
        <div class="background-cards">
            <section class="dashboard">
                <h1>Ingressos Ativos</h1>

                <div class="carteira-carrosel">
                    <?php if (!empty($pagamentos)): ?>
                        <?php foreach ($pagamentos as $pagamento): ?>
                            <div class="carteira-card">
                                <img src="../imagens/zomo-logo.jpg" alt="Evento" class="imagem-festa">
                                <div class="ingresso-info">
                                    <h3><?= htmlspecialchars($pagamento['nome_evento']) ?></h3>
                                    <p>Data: <?= date('d/m/Y', strtotime($pagamento['data_evento'])) ?></p>
                                    <p>Local: <?= htmlspecialchars($pagamento['localidade_evento']) ?></p>
                                    <p>Data do Pagamento: <?= date('d/m/Y H:i', strtotime($pagamento['data_pagamento'])) ?></p>
                                </div>
                                <a class="ver-carteira" href="../tela-de-compra/tela-de-compra.php?id_evento=<?= $pagamento['id_evento']; ?>">Ver Ingresso</a>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Nenhum pagamento encontrado.</p>
                    <?php endif; ?>
                </div>

            </section>
        </div>
    </main>

    <footer id="footer"></footer>

    <script src="paginacao.js"></script>

    <script>
        fetch('../detalhes/cabeçalho.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('header').innerHTML = data;
            });

        fetch('../detalhes/rodape.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer').innerHTML = data;
            });

        let menuVisible = false;

        function toggleMenu() {
            const menu = document.querySelector('.dropdown-menu');
            menuVisible = !menuVisible;
            menu.style.display = menuVisible ? 'block' : 'none';
        }

        document.addEventListener('click', function (event) {
            const menu = document.querySelector('.dropdown-menu');
            const menuButton = document.querySelector('.menu-icon');

            if (menuVisible && !menu.contains(event.target) && !menuButton.contains(event.target)) {
                menuVisible = false;
                menu.style.display = 'none';
            }
        });
    </script>
</body>
</html>
