document.addEventListener("DOMContentLoaded", () => {
    const tableBody = document.querySelector(".clientes-tabela tbody");
    const rows = Array.from(tableBody.querySelectorAll("tr"));
    const carouselContainer = document.querySelector(".clientes-carrossel");
    const prevButton = document.querySelector("#prevButton");
    const nextButton = document.querySelector("#nextButton");
    const pageIndicator = document.querySelector("#paginaAtual");
    const maxRowsPerPage = 10;
    let currentPage = 0;

    function createPages() {
      carouselContainer.innerHTML = "";
      const totalPages = Math.ceil(rows.length / maxRowsPerPage);

      for (let i = 0; i < totalPages; i++) {
        const start = i * maxRowsPerPage;
        const end = start + maxRowsPerPage;
        const pageRows = rows.slice(start, end);

        const tableWrapper = document.createElement("div");
        tableWrapper.classList.add("clientes-card");
        if (i === 0) tableWrapper.classList.add("active"); // Mostra a primeira página inicialmente

        const table = document.createElement("table");
        table.classList.add("clientes-tabela");

        const tableHead = `
          <thead>
            <tr>
              <th>ID Participante</th>
              <th>Nome</th>
              <th>Email</th>
              <th>Telefone</th>
              <th>Produto</th>
              <th>Quantidade</th>
              <th>Valor Total</th>
            </tr>
          </thead>`;
        const tableBody = document.createElement("tbody");

        pageRows.forEach(row => tableBody.appendChild(row.cloneNode(true)));

        table.innerHTML = tableHead;
        table.appendChild(tableBody);
        tableWrapper.appendChild(table);
        carouselContainer.appendChild(tableWrapper);
      }
    }

    function updateCarousel() {
      const cards = carouselContainer.querySelectorAll(".clientes-card");
      const totalPages = cards.length;

      cards.forEach((card, index) => {
        card.classList.remove("active");
        if (index === currentPage) {
          card.classList.add("active");
        }
      });

      pageIndicator.textContent = `Página ${currentPage + 1} de ${totalPages}`;
      prevButton.disabled = currentPage === 0;
      nextButton.disabled = currentPage === totalPages - 1;
    }

    prevButton.addEventListener("click", () => {
      if (currentPage > 0) {
        currentPage--;
        updateCarousel();
      }
    });

    nextButton.addEventListener("click", () => {
      const totalPages = Math.ceil(rows.length / maxRowsPerPage);
      if (currentPage < totalPages - 1) {
        currentPage++;
        updateCarousel();
      }
    });

    createPages();
    updateCarousel();
  });
