document.addEventListener("DOMContentLoaded", () => {
  const popupConfirmacao = document.getElementById("popupConfirmacao");
  const confirmarBtn = document.getElementById("confirmarExclusao");
  const cancelarBtn = document.getElementById("cancelarExclusao");

  const popupSenha = document.getElementById("popupSenha");
  const confirmarSenhaBtn = document.getElementById("confirmarSenha");
  const cancelarSenhaBtn = document.getElementById("cancelarSenha");
  const senhaInput = document.getElementById("senhaExclusao");

  document.querySelectorAll(".botaoexclusao[type='submit']").forEach((botao) => {
    botao.addEventListener("click", (e) => {
      e.preventDefault();
      popupConfirmacao.style.display = "flex";
    });
  });

  cancelarBtn.addEventListener("click", () => {
    popupConfirmacao.style.display = "none";
  });

  confirmarBtn.addEventListener("click", () => {
    popupConfirmacao.style.display = "none";
    popupSenha.style.display = "flex";
  });

  cancelarSenhaBtn.addEventListener("click", () => {
    popupSenha.style.display = "none";
  });

  confirmarSenhaBtn.addEventListener("click", () => {
    console.log("Ação executada sem comparação de senha.");
    popupSenha.style.display = "none";
    senhaInput.value = "";
  });

  popupConfirmacao.addEventListener("click", (e) => {
    if (e.target === popupConfirmacao) {
      popupConfirmacao.style.display = "none";
    }
  });

  popupSenha.addEventListener("click", (e) => {
    if (e.target === popupSenha) {
      popupSenha.style.display = "none";
    }
  });
});
